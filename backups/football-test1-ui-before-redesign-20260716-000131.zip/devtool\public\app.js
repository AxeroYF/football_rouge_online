const RARITY_LABELS = {
  common: "普通",
  rare: "稀有",
  epic: "史诗",
  legendary: "传奇",
};

const ROLE_GROUP_LABELS = {
  ANY: "全位置",
  GK: "门将",
  DEF: "后卫",
  MID: "中场",
  ATT: "前锋",
};

const ROLES = ["GK", "RB", "CB", "LB", "WB", "DM", "CM", "AM", "RM", "LM", "RW", "LW", "CF", "ST"];

const ATTRIBUTE_GROUPS = [
  {
    name: "技术",
    fields: ["passing", "firstTouch", "dribbling", "crossing", "finishing", "longShots", "heading", "setPieces"],
  },
  {
    name: "防守与意识",
    fields: ["tackling", "marking", "positioning", "vision", "decisions", "composure", "offBall", "discipline"],
  },
  {
    name: "身体",
    fields: ["pace", "acceleration", "strength", "stamina", "agility", "jumping", "workRate", "aggression"],
  },
  {
    name: "门将",
    fields: ["goalkeeping", "reflexes"],
  },
];

const ATTRIBUTE_LABELS = {
  passing: "传球",
  firstTouch: "停球",
  dribbling: "盘带",
  crossing: "传中",
  finishing: "射门",
  longShots: "远射",
  heading: "头球",
  setPieces: "定位球",
  tackling: "抢断",
  marking: "盯人",
  positioning: "站位",
  vision: "视野",
  decisions: "决策",
  composure: "冷静",
  offBall: "无球",
  discipline: "纪律",
  pace: "速度",
  acceleration: "加速",
  strength: "力量",
  stamina: "耐力",
  agility: "灵活",
  jumping: "弹跳",
  workRate: "投入",
  aggression: "侵略性",
  goalkeeping: "守门",
  reflexes: "反应",
};

const TACTIC_FIELDS = {
  tempo: "节奏",
  directness: "直接程度",
  width: "进攻宽度",
  pressing: "逼抢强度",
  defensiveLine: "防线高度",
  risk: "冒险程度",
  tackleIntensity: "抢断强度",
  counterAttack: "反击倾向",
  crossing: "传中倾向",
  setPieceFocus: "定位球投入",
  timeWasting: "拖延时间",
};

const FORMATION_FIELDS = {
  defensiveBalance: "防守平衡",
  midfieldDensity: "中场密度",
  attackingNumbers: "进攻人数",
};

const COACH_FIELDS = {
  attack: "进攻指导",
  defense: "防守指导",
  adaptability: "临场适应",
  substitutions: "换人倾向",
};

const TEAM_STATE_FIELDS = {
  chemistry: "球队默契",
  morale: "球队士气",
  form: "近期状态",
};

const VIEW_META = {
  traits: {
    eyebrow: "CONTENT SYSTEM / 01",
    title: "特性卡管理",
    description: "设计卡牌、调整效果参数，并维护随机卡池。",
  },
  simulation: {
    eyebrow: "MATCH LAB / 02",
    title: "比赛模拟实验室",
    description: "调整环境、球队和战术参数，观察单场事件与批量概率。",
  },
  players: {
    eyebrow: "ROSTER DATA / 03",
    title: "球员卡管理",
    description: "维护球员基础资料、26项能力、即时状态和特性槽。",
  },
};

const app = {
  state: null,
  dirty: false,
  activeView: "traits",
  selectedTraitId: null,
  selectedPlayerId: null,
  traitRuleDrafts: new Map(),
  simulationConfig: null,
  simulationResult: null,
  toastTimer: null,
};

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function uniqueId(prefix, existing) {
  let id = prefix + "-" + Date.now().toString(36);
  let counter = 1;
  while (existing.has(id)) {
    id = prefix + "-" + Date.now().toString(36) + "-" + counter;
    counter += 1;
  }
  return id;
}

function roleGroup(role) {
  if (role === "GK") return "GK";
  if (["CB", "LB", "RB", "FB", "WB"].includes(role)) return "DEF";
  if (["DM", "CM", "AM", "LM", "RM", "WM"].includes(role)) return "MID";
  return "ATT";
}

function initials(name) {
  const value = String(name || "?").trim();
  return value.slice(0, 2).toUpperCase();
}

function overall(player) {
  const keys = player.role === "GK"
    ? ["goalkeeping", "reflexes", "positioning", "composure", "passing"]
    : Object.keys(player.attributes ?? {}).filter((key) => !["goalkeeping", "reflexes"].includes(key));
  if (keys.length === 0) return 50;
  return Math.round(keys.reduce((sum, key) => sum + Number(player.attributes?.[key] ?? 50), 0) / keys.length);
}

function getPath(object, path) {
  return path.split(".").reduce((value, key) => value?.[key], object);
}

function setPath(object, path, value) {
  const keys = path.split(".");
  let cursor = object;
  for (const key of keys.slice(0, -1)) {
    cursor[key] ??= {};
    cursor = cursor[key];
  }
  cursor[keys.at(-1)] = value;
}

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: {
      "content-type": "application/json",
      ...(options.headers ?? {}),
    },
  });
  const payload = await response.json();
  if (!response.ok || !payload.ok) {
    const detail = payload.details?.length ? "\n" + payload.details.join("\n") : "";
    throw new Error((payload.error ?? "请求失败") + detail);
  }
  return payload;
}

function showToast(message, type = "success") {
  const toast = document.querySelector("#toast");
  toast.textContent = message;
  toast.className = "toast visible" + (type === "error" ? " error" : "");
  clearTimeout(app.toastTimer);
  app.toastTimer = setTimeout(() => {
    toast.className = "toast";
  }, 3200);
}

function updateSaveState(mode = app.dirty ? "dirty" : "saved") {
  const status = document.querySelector("#save-state");
  status.className = "save-state";
  if (mode === "saving") {
    status.classList.add("saving");
    status.innerHTML = "<span></span>正在保存";
  } else if (mode === "dirty") {
    status.classList.add("dirty");
    status.innerHTML = "<span></span>有未保存改动";
  } else {
    status.innerHTML = "<span></span>已保存";
  }
}

function markDirty() {
  app.dirty = true;
  updateSaveState("dirty");
}

function commitTraitRuleDrafts() {
  for (const [traitId, draft] of app.traitRuleDrafts.entries()) {
    const trait = app.state.traitCards.find((candidate) => candidate.id === traitId);
    if (!trait) continue;
    try {
      const parsed = JSON.parse(draft);
      if (!Array.isArray(parsed)) throw new Error("规则必须是 JSON 数组");
      trait.rules = parsed;
    } catch (error) {
      app.selectedTraitId = traitId;
      switchView("traits");
      renderTraitEditor();
      throw new Error("“" + trait.name + "”的规则 JSON 无效：" + error.message);
    }
  }
}

async function saveState({ quiet = false } = {}) {
  if (!app.state) return;
  try {
    commitTraitRuleDrafts();
    updateSaveState("saving");
    const payload = await api("/api/state", {
      method: "POST",
      body: JSON.stringify({ state: app.state }),
    });
    app.state = payload.state;
    app.dirty = false;
    renderAll();
    updateSaveState("saved");
    if (!quiet) showToast("所有开发数据已保存，并保留了上一个备份");
  } catch (error) {
    updateSaveState("dirty");
    showToast(error.message, "error");
    throw error;
  }
}

function switchView(view) {
  app.activeView = view;
  document.querySelectorAll(".nav-item").forEach((button) => {
    button.classList.toggle("active", button.dataset.viewTarget === view);
  });
  document.querySelectorAll(".view").forEach((section) => {
    section.classList.toggle("active", section.id === "view-" + view);
  });
  const meta = VIEW_META[view];
  document.querySelector("#view-eyebrow").textContent = meta.eyebrow;
  document.querySelector("#view-title").textContent = meta.title;
  document.querySelector("#view-description").textContent = meta.description;
  if (view === "simulation") renderSimulationForm();
}

function summaryCell(label, value) {
  return '<div class="summary-cell"><span>' + escapeHtml(label) + "</span><strong>" + escapeHtml(value) + "</strong></div>";
}

function renderTraitSummary() {
  const counts = Object.fromEntries(Object.keys(RARITY_LABELS).map((rarity) => [rarity, 0]));
  for (const trait of app.state.traitCards) counts[trait.rarity] = (counts[trait.rarity] ?? 0) + 1;
  document.querySelector("#trait-summary").innerHTML =
    summaryCell("特性卡总数", app.state.traitCards.length) +
    summaryCell("普通 / 稀有", counts.common + " / " + counts.rare) +
    summaryCell("史诗 / 传奇", counts.epic + " / " + counts.legendary) +
    summaryCell("已装备数量", app.state.players.reduce((sum, player) => sum + (player.traitCards?.length ?? 0), 0));
}

function traitMatchesFilter(trait) {
  const query = document.querySelector("#trait-search").value.trim().toLowerCase();
  const rarity = document.querySelector("#trait-rarity-filter").value;
  const role = document.querySelector("#trait-role-filter").value;
  const haystack = [trait.name, trait.id, trait.category, trait.summary, ...(trait.tags ?? [])].join(" ").toLowerCase();
  return (
    (!query || haystack.includes(query)) &&
    (rarity === "all" || trait.rarity === rarity) &&
    (role === "all" || trait.eligibleRoleGroups.includes("ANY") || trait.eligibleRoleGroups.includes(role))
  );
}

function renderTraitList() {
  const list = document.querySelector("#trait-list");
  const traits = app.state.traitCards.filter(traitMatchesFilter);
  if (traits.length === 0) {
    list.innerHTML = '<div class="empty-state"><p>没有符合当前筛选的特性卡。</p></div>';
    return;
  }
  list.innerHTML = traits.map((trait) => {
    const roles = trait.eligibleRoleGroups.map((role) => ROLE_GROUP_LABELS[role] ?? role).join(" · ");
    return (
      '<button class="list-item ' + (trait.id === app.selectedTraitId ? "active" : "") + '" data-trait-id="' + escapeHtml(trait.id) + '">' +
      '<span class="rarity-line ' + escapeHtml(trait.rarity) + '"></span>' +
      '<span class="list-copy"><strong>' + escapeHtml(trait.name) + "</strong><small>" + escapeHtml(roles + " · " + trait.category) + "</small></span>" +
      '<span class="list-meta">' + escapeHtml(RARITY_LABELS[trait.rarity] ?? trait.rarity) + "</span></button>"
    );
  }).join("");
  list.querySelectorAll("[data-trait-id]").forEach((button) => {
    button.addEventListener("click", () => {
      app.selectedTraitId = button.dataset.traitId;
      renderTraitList();
      renderTraitEditor();
    });
  });
}

function traitRoleCheckboxes(trait) {
  return Object.keys(ROLE_GROUP_LABELS).map((role) => {
    const checked = trait.eligibleRoleGroups.includes(role) ? " checked" : "";
    return '<label class="check-pill"><input type="checkbox" data-trait-role="' + role + '"' + checked + ' /><span>' + ROLE_GROUP_LABELS[role] + "</span></label>";
  }).join("");
}

function renderTraitEditor() {
  const editor = document.querySelector("#trait-editor");
  const trait = app.state.traitCards.find((candidate) => candidate.id === app.selectedTraitId);
  if (!trait) {
    editor.innerHTML = '<div class="empty-state"><h2>选择一张特性卡</h2><p>你可以修改数值、适用位置、掉率和底层效果规则。</p></div>';
    return;
  }
  if (!app.traitRuleDrafts.has(trait.id)) {
    app.traitRuleDrafts.set(trait.id, JSON.stringify(trait.rules ?? [], null, 2));
  }
  const roleText = trait.eligibleRoleGroups.map((role) => ROLE_GROUP_LABELS[role] ?? role).join(" · ");
  editor.innerHTML =
    '<div class="editor-head">' +
      '<div class="card-preview ' + escapeHtml(trait.rarity) + '" id="trait-preview">' +
        '<span class="rarity-chip ' + escapeHtml(trait.rarity) + '" id="trait-preview-rarity">' + escapeHtml(RARITY_LABELS[trait.rarity]) + "</span>" +
        '<h3 id="trait-preview-name">' + escapeHtml(trait.name) + "</h3>" +
        '<p id="trait-preview-summary">' + escapeHtml(trait.summary) + "</p>" +
      "</div>" +
      '<div class="editor-title"><p class="panel-label">TRAIT CARD / ' + escapeHtml(trait.id) + "</p><h2>" + escapeHtml(trait.name) + "</h2><p>" + escapeHtml(roleText) + " · " + escapeHtml(trait.tags?.join(" / ") || "暂无标签") + "</p>" +
        '<div class="editor-actions"><button class="button ghost" id="duplicate-trait-button">复制卡牌</button><button class="button danger" id="delete-trait-button">删除</button></div>' +
      "</div>" +
    "</div>" +
    '<div class="form-grid">' +
      '<div class="field"><label for="trait-name-input">卡牌名称</label><input id="trait-name-input" value="' + escapeHtml(trait.name) + '" /></div>' +
      '<div class="field"><label for="trait-id-input">稳定 ID</label><input id="trait-id-input" value="' + escapeHtml(trait.id) + '" /><p class="field-help">修改后会自动更新所有球员引用。</p></div>' +
      '<div class="field"><label for="trait-rarity-input">稀有度</label><select id="trait-rarity-input">' +
        Object.entries(RARITY_LABELS).map(([value, label]) => '<option value="' + value + '"' + (trait.rarity === value ? " selected" : "") + ">" + label + "</option>").join("") +
      "</select></div>" +
      '<div class="field"><label for="trait-category-input">类别</label><input id="trait-category-input" value="' + escapeHtml(trait.category) + '" placeholder="technique / mentality" /></div>' +
      '<div class="field"><label for="trait-weight-input">掉落权重</label><input id="trait-weight-input" type="number" min="0.01" max="100" step="0.05" value="' + escapeHtml(trait.dropWeight ?? 1) + '" /></div>' +
      '<div class="field"><label for="trait-polarity-input">性质</label><select id="trait-polarity-input"><option value="positive"' + (trait.polarity === "positive" ? " selected" : "") + '>正向</option><option value="mixed"' + (trait.polarity === "mixed" ? " selected" : "") + '>双刃</option><option value="negative"' + (trait.polarity === "negative" ? " selected" : "") + ">负面</option></select></div>" +
      '<div class="field span-2"><span class="field-label">适用位置</span><div class="checkbox-row">' + traitRoleCheckboxes(trait) + "</div></div>" +
      '<div class="field span-2"><label for="trait-tags-input">标签</label><input id="trait-tags-input" value="' + escapeHtml((trait.tags ?? []).join(", ")) + '" placeholder="finishing, lateGame, tradeoff" /></div>' +
      '<div class="field span-2"><label for="trait-summary-input">玩家可见效果</label><textarea id="trait-summary-input">' + escapeHtml(trait.summary) + "</textarea></div>" +
      '<div class="field span-2"><label for="trait-rules-input">效果规则 JSON</label><textarea id="trait-rules-input" class="code-field" spellcheck="false">' + escapeHtml(app.traitRuleDrafts.get(trait.id)) + '</textarea><p class="validation-message" id="trait-rules-validation">规则数组会随保存写入；静态属性规则可直接参与当前模拟。</p></div>' +
    "</div>";

  const updatePreview = () => {
    document.querySelector("#trait-preview-name").textContent = trait.name;
    document.querySelector("#trait-preview-summary").textContent = trait.summary;
    const preview = document.querySelector("#trait-preview");
    preview.className = "card-preview " + trait.rarity;
    const chip = document.querySelector("#trait-preview-rarity");
    chip.className = "rarity-chip " + trait.rarity;
    chip.textContent = RARITY_LABELS[trait.rarity];
  };

  document.querySelector("#trait-name-input").addEventListener("input", (event) => {
    trait.name = event.target.value;
    updatePreview();
    markDirty();
    renderTraitList();
  });
  document.querySelector("#trait-id-input").addEventListener("change", (event) => changeTraitId(trait, event.target));
  document.querySelector("#trait-rarity-input").addEventListener("change", (event) => {
    trait.rarity = event.target.value;
    updatePreview();
    markDirty();
    renderTraitSummary();
    renderTraitList();
  });
  document.querySelector("#trait-category-input").addEventListener("input", (event) => { trait.category = event.target.value; markDirty(); });
  document.querySelector("#trait-weight-input").addEventListener("input", (event) => { trait.dropWeight = Number(event.target.value); markDirty(); });
  document.querySelector("#trait-polarity-input").addEventListener("change", (event) => { trait.polarity = event.target.value; markDirty(); });
  document.querySelector("#trait-tags-input").addEventListener("input", (event) => { trait.tags = event.target.value.split(",").map((value) => value.trim()).filter(Boolean); markDirty(); });
  document.querySelector("#trait-summary-input").addEventListener("input", (event) => { trait.summary = event.target.value; updatePreview(); markDirty(); });
  document.querySelectorAll("[data-trait-role]").forEach((checkbox) => {
    checkbox.addEventListener("change", () => {
      let roles = [...document.querySelectorAll("[data-trait-role]:checked")].map((input) => input.dataset.traitRole);
      if (checkbox.dataset.traitRole === "ANY" && checkbox.checked) roles = ["ANY"];
      if (checkbox.dataset.traitRole !== "ANY" && checkbox.checked) roles = roles.filter((role) => role !== "ANY");
      if (roles.length === 0) {
        checkbox.checked = true;
        showToast("至少保留一个适用位置", "error");
        return;
      }
      trait.eligibleRoleGroups = roles;
      renderTraitEditor();
      renderTraitList();
      markDirty();
    });
  });
  document.querySelector("#trait-rules-input").addEventListener("input", (event) => {
    app.traitRuleDrafts.set(trait.id, event.target.value);
    const message = document.querySelector("#trait-rules-validation");
    try {
      const parsed = JSON.parse(event.target.value);
      if (!Array.isArray(parsed)) throw new Error("必须是数组");
      event.target.classList.remove("invalid");
      message.className = "validation-message";
      message.textContent = "规则 JSON 有效，共 " + parsed.length + " 条。";
    } catch (error) {
      event.target.classList.add("invalid");
      message.className = "validation-message error";
      message.textContent = error.message;
    }
    markDirty();
  });
  document.querySelector("#duplicate-trait-button").addEventListener("click", () => duplicateTrait(trait));
  document.querySelector("#delete-trait-button").addEventListener("click", () => deleteTrait(trait));
}

function changeTraitId(trait, input) {
  const nextId = input.value.trim();
  if (!/^[a-z0-9][a-z0-9-]*$/.test(nextId)) {
    input.value = trait.id;
    showToast("稳定 ID 只能使用小写字母、数字和连字符", "error");
    return;
  }
  if (app.state.traitCards.some((candidate) => candidate !== trait && candidate.id === nextId)) {
    input.value = trait.id;
    showToast("这个特性 ID 已经存在", "error");
    return;
  }
  const previousId = trait.id;
  trait.id = nextId;
  for (const player of app.state.players) {
    player.traitCards = (player.traitCards ?? []).map((id) => id === previousId ? nextId : id);
  }
  if (app.traitRuleDrafts.has(previousId)) {
    const draft = app.traitRuleDrafts.get(previousId);
    app.traitRuleDrafts.delete(previousId);
    app.traitRuleDrafts.set(nextId, draft);
  }
  app.selectedTraitId = nextId;
  markDirty();
  renderTraitList();
  renderTraitEditor();
}

function addTrait() {
  const ids = new Set(app.state.traitCards.map((trait) => trait.id));
  const id = uniqueId("trait", ids);
  const trait = {
    id,
    name: "新特性",
    rarity: "common",
    category: "technique",
    eligibleRoleGroups: ["ANY"],
    tags: [],
    polarity: "positive",
    summary: "填写玩家可见的特性效果。",
    rules: [],
    dropWeight: 1,
    maxLevel: 1,
  };
  app.state.traitCards.unshift(trait);
  app.selectedTraitId = id;
  app.traitRuleDrafts.set(id, "[]");
  markDirty();
  renderTraits();
}

function duplicateTrait(source) {
  const ids = new Set(app.state.traitCards.map((trait) => trait.id));
  const copy = clone(source);
  copy.id = uniqueId(source.id + "-copy", ids);
  copy.name = source.name + "·副本";
  app.state.traitCards.unshift(copy);
  app.traitRuleDrafts.set(copy.id, JSON.stringify(copy.rules, null, 2));
  app.selectedTraitId = copy.id;
  markDirty();
  renderTraits();
}

function deleteTrait(trait) {
  const equipped = app.state.players.filter((player) => player.traitCards?.includes(trait.id));
  const message = equipped.length
    ? "这张卡已被 " + equipped.length + " 名球员装备。删除后会从这些球员身上移除，确认继续？"
    : "确认删除“" + trait.name + "”？";
  if (!window.confirm(message)) return;
  app.state.traitCards = app.state.traitCards.filter((candidate) => candidate.id !== trait.id);
  for (const player of app.state.players) {
    player.traitCards = (player.traitCards ?? []).filter((id) => id !== trait.id);
  }
  app.traitRuleDrafts.delete(trait.id);
  app.selectedTraitId = app.state.traitCards[0]?.id ?? null;
  markDirty();
  renderTraits();
}

function renderTraits() {
  renderTraitSummary();
  renderTraitList();
  renderTraitEditor();
}

function renderPlayerSummary() {
  const lineup = app.state.players.filter((player) => player.squadStatus === "lineup").length;
  const averageOverall = app.state.players.length
    ? Math.round(app.state.players.reduce((sum, player) => sum + overall(player), 0) / app.state.players.length)
    : 0;
  document.querySelector("#player-summary").innerHTML =
    summaryCell("球员卡总数", app.state.players.length) +
    summaryCell("球队数量", app.state.teams.length) +
    summaryCell("首发球员", lineup) +
    summaryCell("平均综合", averageOverall);
}

function renderPlayerTeamFilter() {
  const select = document.querySelector("#player-team-filter");
  const previous = select.value || "all";
  select.innerHTML = '<option value="all">全部球队</option>' + app.state.teams.map((team) => '<option value="' + escapeHtml(team.id) + '">' + escapeHtml(team.name) + "</option>").join("");
  select.value = app.state.teams.some((team) => team.id === previous) ? previous : "all";
}

function playerMatchesFilter(player) {
  const query = document.querySelector("#player-search").value.trim().toLowerCase();
  const teamId = document.querySelector("#player-team-filter").value;
  const group = document.querySelector("#player-role-filter").value;
  const team = app.state.teams.find((candidate) => candidate.id === player.teamId);
  const haystack = [player.name, player.id, player.role, team?.name, ...(player.traitCards ?? [])].join(" ").toLowerCase();
  return (
    (!query || haystack.includes(query)) &&
    (teamId === "all" || player.teamId === teamId) &&
    (group === "all" || roleGroup(player.role) === group)
  );
}

function renderPlayerList() {
  const list = document.querySelector("#player-list");
  const players = app.state.players.filter(playerMatchesFilter);
  if (players.length === 0) {
    list.innerHTML = '<div class="empty-state"><p>没有符合当前筛选的球员。</p></div>';
    return;
  }
  list.innerHTML = players.map((player) => {
    const team = app.state.teams.find((candidate) => candidate.id === player.teamId);
    return (
      '<button class="list-item player-list-item ' + (player.id === app.selectedPlayerId ? "active" : "") + '" data-player-id="' + escapeHtml(player.id) + '">' +
      '<span class="player-row-avatar">' + escapeHtml(initials(player.name)) + "</span>" +
      '<span class="list-copy"><strong>' + escapeHtml(player.name) + "</strong><small>" + escapeHtml(team?.name ?? "无球队") + " · " + escapeHtml(player.role) + " · " + escapeHtml(player.squadStatus) + "</small></span>" +
      '<span class="list-meta">' + overall(player) + "</span></button>"
    );
  }).join("");
  list.querySelectorAll("[data-player-id]").forEach((button) => {
    button.addEventListener("click", () => {
      app.selectedPlayerId = button.dataset.playerId;
      renderPlayerList();
      renderPlayerEditor();
    });
  });
}

function attributeControl(player, name) {
  const value = Number(player.attributes?.[name] ?? 50);
  return (
    '<div class="attribute-control"><label for="attr-' + name + '">' + escapeHtml(ATTRIBUTE_LABELS[name] ?? name) + "</label>" +
    '<input id="attr-' + name + '" type="range" min="1" max="99" value="' + value + '" data-attribute-range="' + name + '" style="--range-progress:' + value + '%" />' +
    '<input type="number" min="1" max="99" value="' + value + '" data-attribute-number="' + name + '" /></div>'
  );
}

function stateControl(player, name, label, min = 0, max = 100) {
  const value = Number(player.state?.[name] ?? 50);
  return (
    '<div class="attribute-control"><label for="state-' + name + '">' + label + "</label>" +
    '<input id="state-' + name + '" type="range" min="' + min + '" max="' + max + '" value="' + value + '" data-state-range="' + name + '" style="--range-progress:' + value + '%" />' +
    '<input type="number" min="' + min + '" max="' + max + '" value="' + value + '" data-state-number="' + name + '" /></div>'
  );
}

function eligibleTraitsForPlayer(player) {
  const group = roleGroup(player.role);
  return app.state.traitCards.filter((trait) => trait.eligibleRoleGroups.includes("ANY") || trait.eligibleRoleGroups.includes(group));
}

function traitSlotsHtml(player) {
  const equipped = player.traitCards ?? [];
  const eligible = eligibleTraitsForPlayer(player);
  return [0, 1, 2].map((index) => {
    const current = equipped[index] ?? "";
    const options = eligible
      .filter((trait) => trait.id === current || !equipped.includes(trait.id))
      .map((trait) => '<option value="' + escapeHtml(trait.id) + '"' + (trait.id === current ? " selected" : "") + ">[" + escapeHtml(RARITY_LABELS[trait.rarity]) + "] " + escapeHtml(trait.name) + "</option>")
      .join("");
    return '<div class="trait-slot"><span>SLOT 0' + (index + 1) + '</span><select class="trait-slot-select" data-trait-slot="' + index + '"><option value="">未装备</option>' + options + "</select></div>";
  }).join("");
}

function renderPlayerEditor() {
  const editor = document.querySelector("#player-editor");
  const player = app.state.players.find((candidate) => candidate.id === app.selectedPlayerId);
  if (!player) {
    editor.innerHTML = '<div class="empty-state"><h2>选择一名球员</h2><p>调整球员能力、即时状态、所在球队和特性槽。</p></div>';
    return;
  }
  const team = app.state.teams.find((candidate) => candidate.id === player.teamId);
  const teamOptions = app.state.teams.map((candidate) => '<option value="' + escapeHtml(candidate.id) + '"' + (candidate.id === player.teamId ? " selected" : "") + ">" + escapeHtml(candidate.name) + "</option>").join("");
  const roleOptions = ROLES.map((role) => '<option value="' + role + '"' + (player.role === role ? " selected" : "") + ">" + role + "</option>").join("");
  editor.innerHTML = `
    <div class="editor-head">
      <div class="editor-title player-hero">
        <div class="player-avatar">${escapeHtml(initials(player.name))}</div>
        <div>
          <p class="panel-label">PLAYER CARD / ${escapeHtml(player.id)}</p>
          <h2>${escapeHtml(player.name)}</h2>
          <p>${escapeHtml(team?.name ?? "无球队")} · ${escapeHtml(player.role)} · ${player.traitCards?.length ?? 0} 项特性</p>
        </div>
        <div class="player-overall"><strong>${overall(player)}</strong><span>OVERALL</span></div>
      </div>
      <div class="editor-actions">
        <button class="button ghost" id="duplicate-player-button">复制球员</button>
        <button class="button danger" id="delete-player-button">删除</button>
      </div>
    </div>
    <div class="form-section">
      <div class="form-section-head"><h3>基础资料</h3><span>IDENTITY & ROSTER</span></div>
      <div class="form-grid">
        <div class="field"><label for="player-name-input">姓名</label><input id="player-name-input" value="${escapeHtml(player.name)}" /></div>
        <div class="field"><label for="player-role-input">场上位置</label><select id="player-role-input">${roleOptions}</select></div>
        <div class="field"><label for="player-team-input">球队</label><select id="player-team-input">${teamOptions}</select></div>
        <div class="field"><label for="player-status-input">阵容状态</label><select id="player-status-input">
          <option value="lineup"${player.squadStatus === "lineup" ? " selected" : ""}>首发</option>
          <option value="bench"${player.squadStatus === "bench" ? " selected" : ""}>替补</option>
          <option value="reserve"${player.squadStatus === "reserve" ? " selected" : ""}>预备</option>
        </select></div>
        <div class="field"><label for="player-foot-input">惯用脚</label><select id="player-foot-input">
          <option value="right"${player.preferredFoot === "right" ? " selected" : ""}>右脚</option>
          <option value="left"${player.preferredFoot === "left" ? " selected" : ""}>左脚</option>
          <option value="both"${player.preferredFoot === "both" ? " selected" : ""}>双足</option>
        </select></div>
        <div class="field"><label for="player-height-input">身高（cm）</label><input id="player-height-input" type="number" min="140" max="220" value="${escapeHtml(player.heightCm ?? 180)}" /></div>
      </div>
    </div>
    <div class="form-section"><div class="form-section-head"><h3>特性槽</h3><span>MAX 3</span></div><div class="trait-slots">${traitSlotsHtml(player)}</div></div>
    <div class="form-section"><div class="form-section-head"><h3>即时状态</h3><span>MATCH CONDITION</span></div><div class="attribute-grid">
      ${stateControl(player, "fitness", "体能")}
      ${stateControl(player, "form", "状态")}
      ${stateControl(player, "morale", "士气")}
      ${stateControl(player, "injuryProneness", "受伤倾向")}
    </div></div>
    ${ATTRIBUTE_GROUPS.map((group) => `<div class="form-section"><div class="form-section-head"><h3>${group.name}</h3><span>${group.fields.length} ATTRIBUTES</span></div><div class="attribute-grid">${group.fields.map((name) => attributeControl(player, name)).join("")}</div></div>`).join("")}
  `;

  document.querySelector("#player-name-input").addEventListener("input", (event) => { player.name = event.target.value; markDirty(); renderPlayerList(); });
  document.querySelector("#player-role-input").addEventListener("change", (event) => {
    player.role = event.target.value;
    const eligibleIds = new Set(eligibleTraitsForPlayer(player).map((trait) => trait.id));
    const removed = (player.traitCards ?? []).filter((id) => !eligibleIds.has(id));
    player.traitCards = (player.traitCards ?? []).filter((id) => eligibleIds.has(id));
    markDirty();
    renderPlayers();
    if (removed.length) showToast("已移除 " + removed.length + " 张不再适配新位置的特性卡");
  });
  document.querySelector("#player-team-input").addEventListener("change", (event) => {
    player.teamId = event.target.value;
    synchronizePlayerRoster(player);
    markDirty();
    renderPlayers();
  });
  document.querySelector("#player-status-input").addEventListener("change", (event) => {
    player.squadStatus = event.target.value;
    synchronizePlayerRoster(player);
    markDirty();
    renderPlayerSummary();
    renderPlayerList();
  });
  document.querySelector("#player-foot-input").addEventListener("change", (event) => { player.preferredFoot = event.target.value; markDirty(); });
  document.querySelector("#player-height-input").addEventListener("input", (event) => { player.heightCm = Number(event.target.value); markDirty(); });

  document.querySelectorAll("[data-attribute-range], [data-attribute-number]").forEach((input) => {
    input.addEventListener("input", () => {
      const name = input.dataset.attributeRange ?? input.dataset.attributeNumber;
      const value = Math.max(1, Math.min(99, Number(input.value)));
      player.attributes[name] = value;
      const range = document.querySelector('[data-attribute-range="' + name + '"]');
      const number = document.querySelector('[data-attribute-number="' + name + '"]');
      range.value = value;
      range.style.setProperty("--range-progress", value + "%");
      number.value = value;
      markDirty();
    });
  });
  document.querySelectorAll("[data-state-range], [data-state-number]").forEach((input) => {
    input.addEventListener("input", () => {
      const name = input.dataset.stateRange ?? input.dataset.stateNumber;
      const value = Math.max(0, Math.min(100, Number(input.value)));
      player.state[name] = value;
      const range = document.querySelector('[data-state-range="' + name + '"]');
      const number = document.querySelector('[data-state-number="' + name + '"]');
      range.value = value;
      range.style.setProperty("--range-progress", value + "%");
      number.value = value;
      markDirty();
    });
  });
  document.querySelectorAll("[data-trait-slot]").forEach((select) => {
    select.addEventListener("change", () => {
      const slots = [...document.querySelectorAll("[data-trait-slot]")].map((item) => item.value).filter(Boolean);
      player.traitCards = [...new Set(slots)];
      markDirty();
      renderPlayerEditor();
      renderTraitSummary();
      renderPlayerList();
    });
  });
  document.querySelector("#duplicate-player-button").addEventListener("click", () => duplicatePlayer(player));
  document.querySelector("#delete-player-button").addEventListener("click", () => deletePlayer(player));
}

function synchronizePlayerRoster(player) {
  for (const team of app.state.teams) {
    team.lineupIds = (team.lineupIds ?? []).filter((id) => id !== player.id);
    team.benchIds = (team.benchIds ?? []).filter((id) => id !== player.id);
  }
  const team = app.state.teams.find((candidate) => candidate.id === player.teamId);
  if (!team) return;
  if (player.squadStatus === "lineup") team.lineupIds.push(player.id);
  if (player.squadStatus === "bench") team.benchIds.push(player.id);
}

function createBlankAttributes() {
  return Object.fromEntries(Object.keys(ATTRIBUTE_LABELS).map((name) => [name, name === "goalkeeping" || name === "reflexes" ? 10 : 50]));
}

function addPlayer() {
  const ids = new Set(app.state.players.map((player) => player.id));
  const team = app.state.teams[0];
  const player = {
    id: uniqueId("player", ids),
    name: "新球员",
    teamId: team?.id ?? null,
    squadStatus: "reserve",
    role: "CM",
    preferredFoot: "right",
    heightCm: 180,
    attributes: createBlankAttributes(),
    state: { fitness: 100, form: 50, morale: 50, injuryProneness: 30 },
    traitCards: [],
    legacyTraits: [],
  };
  app.state.players.unshift(player);
  app.selectedPlayerId = player.id;
  markDirty();
  renderPlayers();
}

function duplicatePlayer(source) {
  const ids = new Set(app.state.players.map((player) => player.id));
  const player = clone(source);
  player.id = uniqueId("player", ids);
  player.name = source.name + "·副本";
  player.squadStatus = "reserve";
  app.state.players.unshift(player);
  app.selectedPlayerId = player.id;
  markDirty();
  renderPlayers();
}

function deletePlayer(player) {
  if (!window.confirm("确认删除球员“" + player.name + "”？阵容引用也会一并移除。")) return;
  app.state.players = app.state.players.filter((candidate) => candidate.id !== player.id);
  for (const team of app.state.teams) {
    team.lineupIds = team.lineupIds.filter((id) => id !== player.id);
    team.benchIds = team.benchIds.filter((id) => id !== player.id);
  }
  app.selectedPlayerId = app.state.players[0]?.id ?? null;
  markDirty();
  renderPlayers();
}

function renderPlayers() {
  renderPlayerSummary();
  renderPlayerTeamFilter();
  renderPlayerList();
  renderPlayerEditor();
}

function initializeSimulationConfig() {
  const preset = app.state.simulationPresets[0];
  const homeTeam = app.state.teams.find((team) => team.id === preset?.homeTeamId) ?? app.state.teams[0];
  const awayTeam = app.state.teams.find((team) => team.id === preset?.awayTeamId) ?? app.state.teams[1] ?? app.state.teams[0];
  app.simulationConfig = {
    presetId: preset?.id,
    homeTeamId: homeTeam?.id,
    awayTeamId: awayTeam?.id,
    seed: preset?.seed ?? "devtool",
    matches: preset?.matches ?? 500,
    context: clone(preset?.context ?? {}),
    homeOverride: teamOverrideFrom(homeTeam),
    awayOverride: teamOverrideFrom(awayTeam),
  };
}

function teamOverrideFrom(team) {
  if (!team) return {};
  return {
    formation: clone(team.formation ?? {}),
    tactics: clone(team.tactics ?? {}),
    coach: clone(team.coach ?? {}),
    chemistry: team.chemistry ?? 50,
    morale: team.morale ?? 50,
    form: team.form ?? 50,
  };
}

function teamOptions(selected) {
  return app.state.teams.map((team) => '<option value="' + escapeHtml(team.id) + '"' + (team.id === selected ? " selected" : "") + ">" + escapeHtml(team.name) + "</option>").join("");
}

function sliderControl(label, path, value, min = 0, max = 100, step = 1) {
  const percentage = ((Number(value) - min) / (max - min)) * 100;
  return (
    '<div class="slider-control"><label for="sim-' + escapeHtml(path) + '">' + escapeHtml(label) + "</label>" +
    '<input id="sim-' + escapeHtml(path) + '" type="range" min="' + min + '" max="' + max + '" step="' + step + '" value="' + escapeHtml(value) + '" data-sim-path="' + escapeHtml(path) + '" style="--range-progress:' + percentage + '%" />' +
    '<output>' + escapeHtml(value) + "</output></div>"
  );
}

function pairedControls(fields, prefix, homeTeam, awayTeam) {
  return '<div class="two-team-controls"><div class="team-control-column"><h4>主队 · ' + escapeHtml(homeTeam?.name ?? "—") + "</h4>" +
    Object.entries(fields).map(([key, label]) => sliderControl(label, "homeOverride." + prefix + "." + key, getPath(app.simulationConfig, "homeOverride." + prefix + "." + key) ?? 50)).join("") +
    '</div><div class="team-control-column"><h4>客队 · ' + escapeHtml(awayTeam?.name ?? "—") + "</h4>" +
    Object.entries(fields).map(([key, label]) => sliderControl(label, "awayOverride." + prefix + "." + key, getPath(app.simulationConfig, "awayOverride." + prefix + "." + key) ?? 50)).join("") +
    "</div></div>";
}

function pairedTeamState(homeTeam, awayTeam) {
  return '<div class="two-team-controls"><div class="team-control-column"><h4>主队 · ' + escapeHtml(homeTeam?.name ?? "—") + "</h4>" +
    Object.entries(TEAM_STATE_FIELDS).map(([key, label]) => sliderControl(label, "homeOverride." + key, getPath(app.simulationConfig, "homeOverride." + key) ?? 50)).join("") +
    '</div><div class="team-control-column"><h4>客队 · ' + escapeHtml(awayTeam?.name ?? "—") + "</h4>" +
    Object.entries(TEAM_STATE_FIELDS).map(([key, label]) => sliderControl(label, "awayOverride." + key, getPath(app.simulationConfig, "awayOverride." + key) ?? 50)).join("") +
    "</div></div>";
}

function renderSimulationForm() {
  if (!app.state || !app.simulationConfig) return;
  const form = document.querySelector("#simulation-form");
  const config = app.simulationConfig;
  const homeTeam = app.state.teams.find((team) => team.id === config.homeTeamId);
  const awayTeam = app.state.teams.find((team) => team.id === config.awayTeamId);
  form.innerHTML =
    '<div class="matchup-row"><div class="field"><label for="sim-home-team">主队</label><select id="sim-home-team">' + teamOptions(config.homeTeamId) + '</select></div><div class="versus">VS</div><div class="field"><label for="sim-away-team">客队</label><select id="sim-away-team">' + teamOptions(config.awayTeamId) + "</select></div></div>" +
    '<details class="control-section" open><summary>基础与环境参数</summary><div class="control-section-body">' +
      sliderControl("比赛分钟", "context.minutes", config.context.minutes ?? 90, 60, 120, 1) +
      sliderControl("控球序列", "context.basePossessions", config.context.basePossessions ?? 160, 80, 240, 1) +
      sliderControl("主场优势", "context.homeAdvantage", config.context.homeAdvantage ?? 3.2, 0, 10, 0.1) +
      sliderControl("场地质量", "context.pitchQuality", config.context.pitchQuality ?? 85, 0, 100, 1) +
      sliderControl("降雨", "context.weather.precipitation", config.context.weather?.precipitation ?? 10, 0, 100, 1) +
      sliderControl("风力", "context.weather.wind", config.context.weather?.wind ?? 10, 0, 100, 1) +
      sliderControl("温度", "context.weather.temperature", config.context.weather?.temperature ?? 18, -5, 42, 1) +
    "</div></details>" +
    '<details class="control-section" open><summary>双方战术</summary><div class="control-section-body">' + pairedControls(TACTIC_FIELDS, "tactics", homeTeam, awayTeam) + "</div></details>" +
    '<details class="control-section"><summary>阵型结构与球队状态</summary><div class="control-section-body">' + pairedControls(FORMATION_FIELDS, "formation", homeTeam, awayTeam) + pairedTeamState(homeTeam, awayTeam) + "</div></details>" +
    '<details class="control-section"><summary>教练与裁判</summary><div class="control-section-body">' + pairedControls(COACH_FIELDS, "coach", homeTeam, awayTeam) +
      sliderControl("判罚严格", "context.referee.strictness", config.context.referee?.strictness ?? 50) +
      sliderControl("点球倾向", "context.referee.penaltyBias", config.context.referee?.penaltyBias ?? 50) +
      sliderControl("主场倾向", "context.referee.homeBias", config.context.referee?.homeBias ?? 50) +
    "</div></details>" +
    '<div class="simulation-footer-fields"><div class="field"><label for="sim-matches">批量场次</label><input id="sim-matches" type="number" min="10" max="10000" step="10" value="' + escapeHtml(config.matches) + '" /></div><div class="field span-2"><label for="sim-seed">随机种子</label><input id="sim-seed" value="' + escapeHtml(config.seed) + '" /></div></div>' +
    '<p class="run-note">运行前会自动保存当前特性卡和球员数据。批量场次越大，概率越稳定，但计算时间也越长。</p>';

  document.querySelector("#sim-home-team").addEventListener("change", (event) => {
    config.homeTeamId = event.target.value;
    config.homeOverride = teamOverrideFrom(app.state.teams.find((team) => team.id === event.target.value));
    renderSimulationForm();
  });
  document.querySelector("#sim-away-team").addEventListener("change", (event) => {
    config.awayTeamId = event.target.value;
    config.awayOverride = teamOverrideFrom(app.state.teams.find((team) => team.id === event.target.value));
    renderSimulationForm();
  });
  form.querySelectorAll("[data-sim-path]").forEach((input) => {
    input.addEventListener("input", () => {
      const value = Number(input.value);
      setPath(config, input.dataset.simPath, value);
      input.nextElementSibling.textContent = Number.isInteger(value) ? value : value.toFixed(1);
      const min = Number(input.min);
      const max = Number(input.max);
      input.style.setProperty("--range-progress", ((value - min) / (max - min)) * 100 + "%");
    });
  });
  document.querySelector("#sim-matches").addEventListener("input", (event) => { config.matches = Number(event.target.value); });
  document.querySelector("#sim-seed").addEventListener("input", (event) => { config.seed = event.target.value; });
}

async function runSimulationFromUi() {
  const button = document.querySelector("#run-simulation-button");
  const results = document.querySelector("#simulation-results");
  button.disabled = true;
  button.textContent = "模拟中…";
  results.innerHTML = '<div class="loading-block">正在计算单场过程与批量概率…</div>';
  try {
    if (app.dirty) await saveState({ quiet: true });
    const payload = await api("/api/simulate", {
      method: "POST",
      body: JSON.stringify(app.simulationConfig),
    });
    app.simulationResult = payload.result;
    renderSimulationResults();
  } catch (error) {
    results.innerHTML = '<div class="empty-state large"><h2>模拟失败</h2><p>' + escapeHtml(error.message) + "</p></div>";
    showToast(error.message, "error");
  } finally {
    button.disabled = false;
    button.textContent = "运行模拟";
  }
}

function statRow(label, home, away) {
  return "<tr><th>" + escapeHtml(label) + "</th><td>" + escapeHtml(home) + "</td><td>" + escapeHtml(away) + "</td></tr>";
}

function eventDescription(event) {
  if (event.type === "goal") return escapeHtml(event.team + " · " + event.player + " · " + event.shotType + " · " + event.score);
  if (event.type === "yellowCard") return escapeHtml(event.team + " · " + event.player);
  if (event.type === "redCard") return escapeHtml(event.team + " · " + event.player + " · " + event.reason);
  if (event.type === "injury") return escapeHtml(event.team + " · " + event.player);
  if (event.type === "substitution") return escapeHtml(event.team + " · " + event.playerOut + " → " + event.playerIn);
  if (event.type === "penaltyAwarded") return escapeHtml(event.team + " 获得点球");
  return escapeHtml(event.team ?? "比赛事件");
}

function eventTypeLabel(type) {
  return {
    goal: "进球",
    yellowCard: "黄牌",
    redCard: "红牌",
    injury: "伤病",
    substitution: "换人",
    penaltyAwarded: "点球",
  }[type] ?? type;
}

function renderSimulationResults() {
  const container = document.querySelector("#simulation-results");
  const { single, batch, meta } = app.simulationResult;
  const probabilities = [
    ["主胜", batch.probabilities.homeWin],
    ["平局", batch.probabilities.draw],
    ["客胜", batch.probabilities.awayWin],
  ];
  const stats = single.stats;
  const pendingNote = meta.traitRulesPending > 0
    ? '<div class="pending-note">本次应用了 ' + meta.traitRulesApplied + " 条静态特性规则；另有 " + meta.traitRulesPending + " 条临场条件规则已保存，但尚未接入比赛运行时。</div>"
    : '<div class="pending-note">本次应用了 ' + meta.traitRulesApplied + " 条特性规则，没有待接入规则。</div>";
  const probabilityHtml = probabilities.map(([label, probability]) => `
    <div class="probability-card">
      <span>${label}</span><strong>${(probability * 100).toFixed(1)}%</strong>
      <div class="probability-bar"><i style="width:${probability * 100}%"></i></div>
    </div>`).join("");
  const eventHtml = single.events.length
    ? single.events.map((event) => `
      <div class="event-row ${escapeHtml(event.type)}">
        <span class="event-minute">${event.minute}′</span>
        <span class="event-type">${escapeHtml(eventTypeLabel(event.type))}</span>
        <span>${eventDescription(event)}</span>
      </div>`).join("")
    : '<div class="event-row"><span>—</span><span>事件</span><span>本场没有关键事件</span></div>';
  container.innerHTML = `
    <div class="result-head">
      <div class="scoreboard">
        <div class="score-team"><span>HOME</span><strong>${escapeHtml(single.homeTeam)}</strong></div>
        <div class="score-value">${single.score.home} : ${single.score.away}</div>
        <div class="score-team"><span>AWAY</span><strong>${escapeHtml(single.awayTeam)}</strong></div>
      </div>
      <div class="simulation-meta">种子 ${escapeHtml(single.seed)} · ${batch.matches.toLocaleString("zh-CN")} 场 · ${(meta.durationMs / 1000).toFixed(2)} 秒</div>
    </div>
    <div class="result-body">
      <div class="probability-grid">${probabilityHtml}</div>
      <div class="result-section"><h3>单场数据</h3><table class="stats-table">
        <thead><tr><th>指标</th><td>${escapeHtml(single.homeTeam)}</td><td>${escapeHtml(single.awayTeam)}</td></tr></thead>
        <tbody>
          ${statRow("进球", stats.home.goals, stats.away.goals)}
          ${statRow("xG", stats.home.xg, stats.away.xg)}
          ${statRow("射门", stats.home.shots, stats.away.shots)}
          ${statRow("射正", stats.home.shotsOnTarget, stats.away.shotsOnTarget)}
          ${statRow("控球", stats.home.possession + "%", stats.away.possession + "%")}
          ${statRow("犯规", stats.home.fouls, stats.away.fouls)}
          ${statRow("黄牌", stats.home.yellowCards, stats.away.yellowCards)}
          ${statRow("红牌", stats.home.redCards, stats.away.redCards)}
        </tbody>
      </table></div>
      <div class="result-section"><h3>批量均值</h3><table class="stats-table"><tbody>
        ${statRow("平均进球", batch.averages.homeGoals, batch.averages.awayGoals)}
        ${statRow("平均 xG", batch.averages.homeXg, batch.averages.awayXg)}
        ${statRow("平均射门", batch.averages.homeShots, batch.averages.awayShots)}
        ${statRow("平均牌数", batch.averages.homeCards, batch.averages.awayCards)}
      </tbody></table></div>
      <div class="result-section"><h3>常见比分</h3><div class="scoreline-grid">
        ${batch.commonScorelines.map((item) => `<span class="scoreline-chip"><b>${item.score}</b> · ${(item.probability * 100).toFixed(1)}%</span>`).join("")}
      </div></div>
      <div class="result-section"><h3>单场事件</h3><div class="event-list">${eventHtml}</div></div>
      ${pendingNote}
    </div>`;
}

function exportDatabase() {
  commitTraitRuleDrafts();
  const blob = new Blob([JSON.stringify(app.state, null, 2) + "\n"], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = "touchline-lab-" + new Date().toISOString().slice(0, 10) + ".json";
  link.click();
  URL.revokeObjectURL(url);
  showToast("开发数据已导出");
}

async function importDatabase(file) {
  if (!file) return;
  try {
    const state = JSON.parse(await file.text());
    if (!window.confirm("导入会替换当前开发数据，并自动保留旧数据备份。确认继续？")) return;
    const payload = await api("/api/state", { method: "POST", body: JSON.stringify({ state }) });
    app.state = payload.state;
    app.traitRuleDrafts.clear();
    app.selectedTraitId = app.state.traitCards[0]?.id ?? null;
    app.selectedPlayerId = app.state.players[0]?.id ?? null;
    app.dirty = false;
    initializeSimulationConfig();
    renderAll();
    updateSaveState("saved");
    showToast("数据导入完成");
  } catch (error) {
    showToast("导入失败：" + error.message, "error");
  }
}

async function resetDatabase() {
  if (!window.confirm("确认恢复初始数据？当前数据会先保存为备份。")) return;
  try {
    const payload = await api("/api/reset", { method: "POST", body: "{}" });
    app.state = payload.state;
    app.traitRuleDrafts.clear();
    app.selectedTraitId = app.state.traitCards[0]?.id ?? null;
    app.selectedPlayerId = app.state.players[0]?.id ?? null;
    app.dirty = false;
    initializeSimulationConfig();
    renderAll();
    updateSaveState("saved");
    showToast("已恢复初始开发数据");
  } catch (error) {
    showToast(error.message, "error");
  }
}

function renderAll() {
  renderTraits();
  renderPlayers();
  renderSimulationForm();
}

function bindStaticEvents() {
  document.querySelectorAll("[data-view-target]").forEach((button) => {
    button.addEventListener("click", () => switchView(button.dataset.viewTarget));
  });
  document.querySelector("#save-button").addEventListener("click", () => saveState());
  document.querySelector("#export-button").addEventListener("click", exportDatabase);
  document.querySelector("#import-button").addEventListener("click", () => document.querySelector("#import-file").click());
  document.querySelector("#import-file").addEventListener("change", (event) => importDatabase(event.target.files[0]));
  document.querySelector("#reset-data-button").addEventListener("click", resetDatabase);
  document.querySelector("#add-trait-button").addEventListener("click", addTrait);
  document.querySelector("#add-player-button").addEventListener("click", addPlayer);
  document.querySelector("#run-simulation-button").addEventListener("click", runSimulationFromUi);
  for (const selector of ["#trait-search", "#trait-rarity-filter", "#trait-role-filter"]) {
    document.querySelector(selector).addEventListener("input", renderTraitList);
    document.querySelector(selector).addEventListener("change", renderTraitList);
  }
  for (const selector of ["#player-search", "#player-team-filter", "#player-role-filter"]) {
    document.querySelector(selector).addEventListener("input", renderPlayerList);
    document.querySelector(selector).addEventListener("change", renderPlayerList);
  }
  window.addEventListener("beforeunload", (event) => {
    if (!app.dirty) return;
    event.preventDefault();
  });
}

async function start() {
  bindStaticEvents();
  try {
    const payload = await api("/api/state");
    app.state = payload.state;
    app.selectedTraitId = app.state.traitCards[0]?.id ?? null;
    app.selectedPlayerId = app.state.players[0]?.id ?? null;
    initializeSimulationConfig();
    renderAll();
    updateSaveState("saved");
  } catch (error) {
    document.querySelector(".content-area").innerHTML = '<div class="empty-state large"><h2>开发数据加载失败</h2><p>' + escapeHtml(error.message) + "</p></div>";
    showToast(error.message, "error");
  }
}

start();
