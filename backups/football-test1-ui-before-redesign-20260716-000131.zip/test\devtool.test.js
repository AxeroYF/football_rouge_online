import test from "node:test";
import assert from "node:assert/strict";
import { createDefaultDatabase } from "../devtool/default-data.js";
import { buildTeamFromDatabase, runSimulation } from "../devtool/simulation.js";
import { hasCorruptedText, repairCorruptedDatabaseText, validateDatabase } from "../devtool/store.js";

test("开发工具默认数据库结构有效", () => {
  const state = createDefaultDatabase();
  assert.deepEqual(validateDatabase(state), []);
  assert.equal(state.traitCards.length, 80);
  assert.equal(state.teams.length, 2);
  assert.ok(state.players.length >= 30);
});

test("静态特性属性规则会进入开发工具模拟阵容", () => {
  const state = createDefaultDatabase();
  const team = state.teams[0];
  const striker = state.players.find(
    (player) => team.lineupIds.includes(player.id) && player.role === "ST",
  );
  const originalHeading = striker.attributes.heading;
  const originalPace = striker.attributes.pace;
  striker.traitCards = ["aerial-beacon"];
  const built = buildTeamFromDatabase(state, team.id, {}, state.simulationPresets[0].context);
  const simulatedStriker = built.team.lineup.find((player) => player.id === striker.id);
  assert.equal(simulatedStriker.attributes.heading, originalHeading + 5);
  assert.equal(simulatedStriker.attributes.pace, originalPace - 2);
  assert.equal(built.audit.applied, 1);
  assert.equal(built.audit.pending, 1);
});

test("开发工具可以使用保存的数据运行单场与批量模拟", () => {
  const state = createDefaultDatabase();
  const result = runSimulation(state, { matches: 20, seed: "devtool-test" });
  assert.equal(result.batch.matches, 20);
  assert.ok(Number.isInteger(result.single.score.home));
  assert.ok(Number.isInteger(result.single.score.away));
  const probabilityTotal =
    result.batch.probabilities.homeWin +
    result.batch.probabilities.draw +
    result.batch.probabilities.awayWin;
  assert.ok(Math.abs(probabilityTotal - 1) < 0.001);
});

test("乱码修复按稳定ID恢复文字并保留数值调整", () => {
  const state = createDefaultDatabase();
  const originalPace = state.players[0].attributes.pace;
  state.meta.title = "?????";
  state.traitCards[0].name = "????";
  state.traitCards[0].summary = "????????+4????";
  state.players[0].name = "???? 1";
  state.players[0].attributes.pace = originalPace + 7;

  const repaired = repairCorruptedDatabaseText(state);
  assert.equal(repaired.state.meta.title, "场边实验室");
  assert.equal(repaired.state.traitCards[0].name, "一脚出球");
  assert.equal(repaired.state.players[0].name, "河湾竞技 1");
  assert.equal(repaired.state.players[0].attributes.pace, originalPace + 7);
  assert.ok(repaired.repairedFields >= 4);
  assert.equal(hasCorruptedText("正常的中文问句？"), false);
});
