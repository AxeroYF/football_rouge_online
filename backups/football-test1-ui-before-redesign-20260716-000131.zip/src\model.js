import { Random } from "./random.js";

const DEFAULT_CONTEXT = {
  minutes: 90,
  basePossessions: 160,
  homeAdvantage: 3.2,
  weather: {
    precipitation: 10,
    wind: 10,
    temperature: 18,
  },
  pitchQuality: 85,
  referee: {
    strictness: 50,
    penaltyBias: 50,
    homeBias: 50,
  },
};

const DEFAULT_TACTICS = {
  tempo: 50,
  directness: 50,
  width: 50,
  pressing: 50,
  defensiveLine: 50,
  risk: 50,
  tackleIntensity: 50,
  counterAttack: 50,
  crossing: 50,
  setPieceFocus: 50,
  timeWasting: 20,
};

const DEFAULT_FORMATION = {
  name: "4-3-3",
  defensiveBalance: 50,
  midfieldDensity: 50,
  attackingNumbers: 50,
};

const DEFAULT_COACH = {
  attack: 50,
  defense: 50,
  adaptability: 50,
  substitutions: 50,
};

const ATTRIBUTE_DEFAULT = 50;
const EPSILON = 1e-9;

function clamp(value, minimum, maximum) {
  return Math.max(minimum, Math.min(maximum, value));
}

function logistic(value) {
  return 1 / (1 + Math.exp(-value));
}

function logit(probability) {
  const bounded = clamp(probability, EPSILON, 1 - EPSILON);
  return Math.log(bounded / (1 - bounded));
}

function average(values, fallback = 50) {
  if (values.length === 0) return fallback;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function attribute(player, name) {
  return player.attributes?.[name] ?? ATTRIBUTE_DEFAULT;
}

function roleGroup(role) {
  if (role === "GK") return "GK";
  if (["CB", "LB", "RB", "FB", "WB"].includes(role)) return "DEF";
  if (["DM", "CM", "AM", "LM", "RM", "WM"].includes(role)) return "MID";
  return "ATT";
}

function mergeContext(context = {}) {
  return {
    ...DEFAULT_CONTEXT,
    ...context,
    weather: { ...DEFAULT_CONTEXT.weather, ...context.weather },
    referee: { ...DEFAULT_CONTEXT.referee, ...context.referee },
  };
}

function teamSettings(team) {
  return {
    tactics: { ...DEFAULT_TACTICS, ...team.tactics },
    formation: { ...DEFAULT_FORMATION, ...team.formation },
    coach: { ...DEFAULT_COACH, ...team.coach },
  };
}

function playerStateAdjustment(player) {
  const state = player.state ?? {};
  return (
    ((state.form ?? 50) - 50) * 0.055 +
    ((state.morale ?? 50) - 50) * 0.04 +
    ((state.fitness ?? 100) - 100) * 0.16
  );
}

function fatiguePenalty(player, minute, tactics, context) {
  const stamina = attribute(player, "stamina");
  const pressLoad = 0.75 + tactics.pressing / 180;
  const tempoLoad = 0.8 + tactics.tempo / 250;
  const weatherLoad =
    1 +
    context.weather.precipitation / 500 +
    Math.max(0, context.weather.temperature - 25) / 100;
  const staminaLoad = 3.2 + (100 - stamina) * 0.055;
  return (minute / context.minutes) * pressLoad * tempoLoad * weatherLoad * staminaLoad;
}

function playerMetric(player, weights, minute, tactics, context) {
  let totalWeight = 0;
  let value = 0;
  for (const [name, weight] of Object.entries(weights)) {
    value += attribute(player, name) * weight;
    totalWeight += weight;
  }
  const base = totalWeight > 0 ? value / totalWeight : ATTRIBUTE_DEFAULT;
  return base + playerStateAdjustment(player) - fatiguePenalty(player, minute, tactics, context);
}

function groupMetric(players, groups, weights, minute, tactics, context) {
  let selected = players.filter((player) => groups.includes(roleGroup(player.role)));
  if (selected.length === 0) selected = players;
  return average(
    selected.map((player) => playerMetric(player, weights, minute, tactics, context)),
  );
}

function topMetric(players, weights, count, minute, tactics, context) {
  const values = players
    .map((player) => playerMetric(player, weights, minute, tactics, context))
    .sort((left, right) => right - left)
    .slice(0, count);
  return average(values);
}

function activePlayers(runtime) {
  return runtime.lineup.filter(
    (player) => !runtime.sentOff.has(player.id) && !runtime.injuredOut.has(player.id),
  );
}

export function deriveTeamMetrics(runtime, minute, rawContext = {}) {
  const context = mergeContext(rawContext);
  const cacheKey = [
    runtime.version ?? 0,
    Math.floor(minute / 4),
    context.minutes,
    context.pitchQuality,
    context.weather.precipitation,
    context.weather.wind,
    context.weather.temperature,
  ].join(":");
  if (runtime.metricCache?.has(cacheKey)) {
    return runtime.metricCache.get(cacheKey);
  }
  const { tactics, formation, coach } = teamSettings(runtime.team);
  const players = activePlayers(runtime);
  const initialSize = runtime.initialLineupSize;
  const missingPlayers = Math.max(0, initialSize - players.length);
  const teamState =
    ((runtime.team.chemistry ?? 50) - 50) * 0.055 +
    ((runtime.team.morale ?? 50) - 50) * 0.04 +
    ((runtime.team.form ?? 50) - 50) * 0.035;

  const goalkeeper = groupMetric(
    players,
    ["GK"],
    { goalkeeping: 0.46, reflexes: 0.27, positioning: 0.17, composure: 0.1 },
    minute,
    tactics,
    context,
  );
  const defenderCore = groupMetric(
    players,
    ["DEF"],
    { tackling: 0.25, marking: 0.25, positioning: 0.21, decisions: 0.11, strength: 0.1, pace: 0.08 },
    minute,
    tactics,
    context,
  );
  const midfieldDefense = groupMetric(
    players,
    ["MID"],
    { tackling: 0.24, positioning: 0.22, workRate: 0.2, decisions: 0.15, stamina: 0.11, strength: 0.08 },
    minute,
    tactics,
    context,
  );
  const midfield = groupMetric(
    players,
    ["MID"],
    { passing: 0.25, firstTouch: 0.16, vision: 0.2, decisions: 0.17, composure: 0.1, stamina: 0.12 },
    minute,
    tactics,
    context,
  );
  const defenderBuildUp = groupMetric(
    players,
    ["DEF"],
    { passing: 0.34, firstTouch: 0.16, decisions: 0.24, composure: 0.16, vision: 0.1 },
    minute,
    tactics,
    context,
  );
  const attackReception = groupMetric(
    players,
    ["ATT"],
    { firstTouch: 0.25, offBall: 0.23, strength: 0.12, pace: 0.13, decisions: 0.14, composure: 0.13 },
    minute,
    tactics,
    context,
  );
  const progression = groupMetric(
    players,
    ["MID", "ATT"],
    { passing: 0.2, dribbling: 0.18, vision: 0.18, firstTouch: 0.13, pace: 0.11, decisions: 0.13, offBall: 0.07 },
    minute,
    tactics,
    context,
  );
  const creation = groupMetric(
    players,
    ["MID", "ATT"],
    { vision: 0.23, passing: 0.2, dribbling: 0.15, offBall: 0.16, decisions: 0.16, crossing: 0.1 },
    minute,
    tactics,
    context,
  );
  const finishing = groupMetric(
    players,
    ["ATT"],
    { finishing: 0.43, composure: 0.21, offBall: 0.18, firstTouch: 0.08, heading: 0.1 },
    minute,
    tactics,
    context,
  );
  const press = groupMetric(
    players,
    ["DEF", "MID", "ATT"],
    { workRate: 0.27, stamina: 0.23, aggression: 0.14, pace: 0.14, decisions: 0.12, positioning: 0.1 },
    minute,
    tactics,
    context,
  );
  const pressResistance = groupMetric(
    players,
    ["DEF", "MID"],
    { firstTouch: 0.24, passing: 0.24, composure: 0.2, decisions: 0.2, agility: 0.12 },
    minute,
    tactics,
    context,
  );
  const transitionDefense = groupMetric(
    players,
    ["DEF", "MID"],
    { positioning: 0.23, pace: 0.2, decisions: 0.19, workRate: 0.16, tackling: 0.14, stamina: 0.08 },
    minute,
    tactics,
    context,
  );
  const aerialAttack = groupMetric(
    players,
    ["DEF", "ATT"],
    { heading: 0.43, strength: 0.22, offBall: 0.2, jumping: 0.15 },
    minute,
    tactics,
    context,
  );
  const discipline = groupMetric(
    players,
    ["DEF", "MID", "ATT"],
    { composure: 0.32, decisions: 0.3, discipline: 0.25, aggression: -0.13 },
    minute,
    tactics,
    context,
  );
  const setPieceTaker = topMetric(
    players,
    { setPieces: 0.56, crossing: 0.18, longShots: 0.13, composure: 0.13 },
    3,
    minute,
    tactics,
    context,
  );
  const stamina = groupMetric(
    players,
    ["DEF", "MID", "ATT"],
    { stamina: 0.65, workRate: 0.35 },
    minute,
    tactics,
    context,
  );

  const shared = teamState;
  const shortHandAttack = missingPlayers * 4.7;
  const shortHandDefense = missingPlayers * 6.2;
  const rainPassingPenalty =
    (context.weather.precipitation / 100) * (100 - context.pitchQuality) * 0.07;
  const coachAttack = (coach.attack - 50) * 0.045;
  const coachDefense = (coach.defense - 50) * 0.045;

  const metrics = {
    goalkeeper: goalkeeper + shared - missingPlayers * 1.4,
    defending:
      defenderCore * 0.77 +
      midfieldDefense * 0.23 +
      shared +
      (formation.defensiveBalance - 50) * 0.05 +
      coachDefense -
      shortHandDefense,
    midfieldDefense:
      midfieldDefense +
      shared +
      (formation.midfieldDensity - 50) * 0.045 -
      missingPlayers * 5.2,
    midfieldControl:
      midfield +
      shared +
      (formation.midfieldDensity - 50) * 0.06 +
      (coach.adaptability - 50) * 0.025 -
      missingPlayers * 5.4 -
      rainPassingPenalty,
    buildUp:
      defenderBuildUp * 0.34 +
      midfield * 0.47 +
      pressResistance * 0.11 +
      goalkeeper * 0.08 +
      shared +
      coachAttack -
      shortHandAttack -
      rainPassingPenalty,
    progression:
      progression * 0.72 +
      attackReception * 0.28 +
      shared +
      coachAttack -
      shortHandAttack -
      rainPassingPenalty * 0.7,
    chanceCreation:
      creation +
      shared +
      (formation.attackingNumbers - 50) * 0.055 +
      coachAttack -
      shortHandAttack,
    finishing: finishing + shared + coachAttack - missingPlayers * 2.8,
    press:
      press +
      shared +
      (coach.defense - 50) * 0.025 -
      missingPlayers * 5.6,
    pressResistance: pressResistance + shared - missingPlayers * 4.3,
    transitionDefense:
      transitionDefense +
      shared +
      (formation.defensiveBalance - 50) * 0.04 +
      coachDefense -
      shortHandDefense,
    shotStopping: goalkeeper * 0.86 + defenderCore * 0.14 + shared + coachDefense,
    aerialAttack: aerialAttack + shared - shortHandAttack,
    setPieceAttack:
      setPieceTaker * 0.58 +
      aerialAttack * 0.42 +
      (tactics.setPieceFocus - 50) * 0.045 +
      shared,
    setPieceDefense:
      defenderCore * 0.49 +
      goalkeeper * 0.27 +
      aerialAttack * 0.24 +
      shared -
      missingPlayers * 5.5,
    discipline: discipline + shared,
    stamina: stamina + shared,
    activePlayers: players.length,
  };
  runtime.metricCache?.set(cacheKey, metrics);
  return metrics;
}

function clonePlayer(player) {
  return {
    ...player,
    attributes: { ...player.attributes },
    state: { ...player.state },
  };
}

function makeRuntime(team, side) {
  return {
    side,
    team,
    lineup: team.lineup.map(clonePlayer),
    bench: (team.bench ?? []).map(clonePlayer),
    initialLineupSize: team.lineup.length,
    sentOff: new Set(),
    injuredOut: new Set(),
    yellowsByPlayer: new Map(),
    substitutionIndex: 0,
    version: 0,
    metricCache: new Map(),
    stats: {
      goals: 0,
      xg: 0,
      shots: 0,
      shotsOnTarget: 0,
      possessionSequences: 0,
      fouls: 0,
      yellows: 0,
      reds: 0,
      corners: 0,
      substitutions: 0,
      injuries: 0,
    },
  };
}

function touchRuntime(runtime) {
  runtime.version += 1;
  runtime.metricCache.clear();
}

function tacticsFor(runtime) {
  return { ...DEFAULT_TACTICS, ...runtime.team.tactics };
}

function matchBehavior(runtime, opponent, minute, context) {
  const goalDifference = runtime.stats.goals - opponent.stats.goals;
  const progress = minute / context.minutes;
  let attack = 0;
  let control = 0;
  let defense = 0;
  let counter = 0;

  if (goalDifference < 0 && progress > 0.55) {
    const urgency = Math.min(2, -goalDifference) * (progress - 0.45);
    attack += 5.2 * urgency;
    control += 2.8 * urgency;
    defense -= 3.4 * urgency;
  }
  if (goalDifference > 0 && progress > 0.65) {
    const protection = Math.min(2, goalDifference) * (progress - 0.55);
    attack -= 2.4 * protection;
    control -= 1.5 * protection;
    defense += 3.5 * protection;
    counter += 3.2 * protection;
  }

  return { attack, control, defense, counter };
}

function pickOffender(runtime, rng) {
  const players = activePlayers(runtime).filter((player) => player.role !== "GK");
  return rng.weighted(
    players,
    (player) =>
      0.4 + attribute(player, "aggression") / 45 + attribute(player, "tackling") / 120,
  );
}

function pickVictim(runtime, rng) {
  const players = activePlayers(runtime).filter((player) => player.role !== "GK");
  return rng.weighted(
    players,
    (player) =>
      0.5 + attribute(player, "dribbling") / 55 + attribute(player, "pace") / 100,
  );
}

function shooterWeight(player) {
  const roleWeights = {
    GK: 0.03,
    CB: 0.35,
    LB: 0.7,
    RB: 0.7,
    FB: 0.7,
    WB: 1.0,
    DM: 0.8,
    CM: 1.25,
    AM: 2.35,
    LM: 1.8,
    RM: 1.8,
    WM: 2.0,
    LW: 2.8,
    RW: 2.8,
    W: 2.8,
    CF: 4.2,
    ST: 4.8,
  };
  return (
    (roleWeights[player.role] ?? 1.8) *
    (0.45 + attribute(player, "offBall") / 100) *
    (0.6 + attribute(player, "finishing") / 160)
  );
}

function pickShooter(runtime, type, rng) {
  const players = activePlayers(runtime);
  if (type === "penalty" || type === "freeKick") {
    return rng.weighted(
      players,
      (player) =>
        Math.max(attribute(player, "setPieces"), attribute(player, "finishing")) ** 2,
    );
  }
  if (type === "corner") {
    return rng.weighted(
      players,
      (player) => shooterWeight(player) * (0.4 + attribute(player, "heading") / 55),
    );
  }
  return rng.weighted(players, shooterWeight);
}

function chooseShotType(attacking, defending, rng) {
  const attackTactics = tacticsFor(attacking);
  const defenseTactics = tacticsFor(defending);
  const weights = [
    {
      type: "throughBall",
      weight: 0.28 + (100 - attackTactics.directness) / 500,
    },
    {
      type: "cutback",
      weight: 0.19 + attackTactics.width / 650,
    },
    {
      type: "cross",
      weight:
        0.11 + attackTactics.crossing / 300 + attackTactics.width / 700,
    },
    {
      type: "longShot",
      weight:
        0.08 + attackTactics.directness / 650 + defenseTactics.defensiveLine / 1200,
    },
    {
      type: "counter",
      weight:
        0.08 +
        attackTactics.counterAttack / 380 +
        defenseTactics.defensiveLine / 700 +
        defenseTactics.risk / 1000,
    },
  ];
  return rng.weighted(weights, (entry) => entry.weight).type;
}

const BASE_XG = {
  throughBall: 0.145,
  cutback: 0.16,
  cross: 0.075,
  longShot: 0.035,
  counter: 0.18,
  freeKick: 0.06,
  corner: 0.085,
  penalty: 0.76,
};

function recordEvent(events, enabled, event) {
  if (enabled) events.push(event);
}

function takeShot({
  attacking,
  defending,
  attackMetrics,
  defenseMetrics,
  minute,
  type,
  context,
  rng,
  events,
  recordEvents,
  allowCorner = true,
}) {
  const shooter = pickShooter(attacking, type, rng);
  if (!shooter) return;

  const shooterFinishing = playerMetric(
    shooter,
    type === "corner"
      ? { heading: 0.48, strength: 0.18, offBall: 0.2, composure: 0.14 }
      : type === "longShot" || type === "freeKick"
        ? { longShots: 0.43, finishing: 0.2, composure: 0.22, setPieces: 0.15 }
        : { finishing: 0.5, composure: 0.24, offBall: 0.16, firstTouch: 0.1 },
    minute,
    tacticsFor(attacking),
    context,
  );

  const windPenalty =
    ["cross", "longShot", "freeKick", "corner"].includes(type)
      ? context.weather.wind / 450
      : 0;
  const creationEdge =
    type === "penalty"
      ? 0
      : (attackMetrics.chanceCreation - defenseMetrics.defending) / 58;
  const chanceXg = clamp(
    logistic(logit(BASE_XG[type]) + creationEdge - windPenalty),
    0.008,
    type === "penalty" ? 0.82 : 0.52,
  );
  const finishingEdge =
    type === "penalty"
      ? (shooterFinishing - 65) / 70
      : (shooterFinishing - defenseMetrics.shotStopping) / 34;
  const goalProbability = clamp(
    logistic(logit(chanceXg) + finishingEdge),
    0.004,
    type === "penalty" ? 0.88 : 0.64,
  );

  attacking.stats.shots += 1;
  attacking.stats.xg += chanceXg;
  const goal = rng.bool(goalProbability);
  const targetRate = clamp(
    0.25 + shooterFinishing * 0.0022 - (type === "longShot" ? 0.06 : 0),
    0.24,
    0.58,
  );
  const nonGoalOnTarget = clamp(
    (targetRate - goalProbability) / Math.max(EPSILON, 1 - goalProbability),
    0,
    0.8,
  );
  const onTarget = goal || rng.bool(nonGoalOnTarget);
  if (onTarget) attacking.stats.shotsOnTarget += 1;

  if (goal) {
    attacking.stats.goals += 1;
    const homeGoals = attacking.side === "home" ? attacking.stats.goals : defending.stats.goals;
    const awayGoals = attacking.side === "away" ? attacking.stats.goals : defending.stats.goals;
    recordEvent(events, recordEvents, {
      minute: Math.ceil(minute),
      type: "goal",
      team: attacking.team.name,
      player: shooter.name,
      shotType: type,
      xg: Number(chanceXg.toFixed(3)),
      score: homeGoals + "-" + awayGoals,
    });
    return;
  }

  if (allowCorner && type !== "penalty" && rng.bool(0.115)) {
    attacking.stats.corners += 1;
    if (rng.bool(0.19)) {
      takeShot({
        attacking,
        defending,
        attackMetrics,
        defenseMetrics,
        minute: Math.min(context.minutes, minute + rng.range(0.1, 0.6)),
        type: "corner",
        context,
        rng,
        events,
        recordEvents,
        allowCorner: false,
      });
    }
  }
}

function tryForcedSubstitution(runtime, player, minute, events, recordEvents) {
  if (!player || runtime.stats.substitutions >= 5) return false;
  const group = roleGroup(player.role);
  const replacementIndex = runtime.bench.findIndex(
    (candidate) => roleGroup(candidate.role) === group,
  );
  if (replacementIndex < 0) return false;
  const lineupIndex = runtime.lineup.findIndex((candidate) => candidate.id === player.id);
  if (lineupIndex < 0) return false;

  const [replacement] = runtime.bench.splice(replacementIndex, 1);
  runtime.lineup[lineupIndex] = replacement;
  runtime.stats.substitutions += 1;
  touchRuntime(runtime);
  recordEvent(events, recordEvents, {
    minute: Math.ceil(minute),
    type: "substitution",
    team: runtime.team.name,
    playerOut: player.name,
    playerIn: replacement.name,
    reason: "injury",
  });
  return true;
}

function maybeInjure(victim, attacking, minute, context, rng, events, recordEvents) {
  if (!victim) return;
  const proneness = victim.state?.injuryProneness ?? 30;
  const fitness = victim.state?.fitness ?? 100;
  const probability =
    0.0025 + proneness / 18000 + Math.max(0, 90 - fitness) / 9000 + minute / 90000;
  if (!rng.bool(probability)) return;

  attacking.stats.injuries += 1;
  recordEvent(events, recordEvents, {
    minute: Math.ceil(minute),
    type: "injury",
    team: attacking.team.name,
    player: victim.name,
  });
  if (!tryForcedSubstitution(attacking, victim, minute, events, recordEvents)) {
    attacking.injuredOut.add(victim.id);
    touchRuntime(attacking);
  }
}

function handleCard(defending, offender, minute, context, rng, events, recordEvents) {
  if (!offender) return;
  const tactics = tacticsFor(defending);
  const strictness = context.referee.strictness;
  const aggression = attribute(offender, "aggression");
  const discipline = attribute(offender, "discipline");
  const cardProbability = clamp(
    0.075 +
      strictness * 0.00135 +
      tactics.tackleIntensity * 0.00065 +
      Math.max(0, aggression - discipline) * 0.0012,
    0.07,
    0.36,
  );
  if (!rng.bool(cardProbability)) return;

  const priorYellows = defending.yellowsByPlayer.get(offender.id) ?? 0;
  const directRedProbability = clamp(
    0.008 + Math.max(0, aggression - 65) * 0.001 + (strictness - 50) * 0.00015,
    0.004,
    0.075,
  );
  if (rng.bool(directRedProbability)) {
    defending.stats.reds += 1;
    defending.sentOff.add(offender.id);
    touchRuntime(defending);
    recordEvent(events, recordEvents, {
      minute: Math.ceil(minute),
      type: "redCard",
      team: defending.team.name,
      player: offender.name,
      reason: "direct",
    });
    return;
  }

  defending.stats.yellows += 1;
  defending.yellowsByPlayer.set(offender.id, priorYellows + 1);
  recordEvent(events, recordEvents, {
    minute: Math.ceil(minute),
    type: "yellowCard",
    team: defending.team.name,
    player: offender.name,
  });
  if (priorYellows + 1 >= 2) {
    defending.stats.reds += 1;
    defending.sentOff.add(offender.id);
    touchRuntime(defending);
    recordEvent(events, recordEvents, {
      minute: Math.ceil(minute),
      type: "redCard",
      team: defending.team.name,
      player: offender.name,
      reason: "secondYellow",
    });
  }
}

function handleFoul({
  stage,
  attacking,
  defending,
  attackMetrics,
  defenseMetrics,
  minute,
  context,
  rng,
  events,
  recordEvents,
}) {
  const baseByStage = { buildUp: 0.075, progression: 0.16, finalThird: 0.195 };
  const defenseTactics = tacticsFor(defending);
  const foulProbability = clamp(
    baseByStage[stage] +
      (defenseTactics.tackleIntensity - 50) * 0.0008 +
      (50 - defenseMetrics.discipline) * 0.001 +
      (context.referee.strictness - 50) * 0.0005,
    0.035,
    0.3,
  );
  if (!rng.bool(foulProbability)) return false;

  defending.stats.fouls += 1;
  const offender = pickOffender(defending, rng);
  const victim = pickVictim(attacking, rng);
  handleCard(defending, offender, minute, context, rng, events, recordEvents);
  maybeInjure(victim, attacking, minute, context, rng, events, recordEvents);

  if (stage === "finalThird") {
    const penaltyProbability = clamp(
      0.018 + (context.referee.penaltyBias - 50) * 0.00018,
      0.006,
      0.04,
    );
    if (rng.bool(penaltyProbability)) {
      recordEvent(events, recordEvents, {
        minute: Math.ceil(minute),
        type: "penaltyAwarded",
        team: attacking.team.name,
      });
      takeShot({
        attacking,
        defending,
        attackMetrics,
        defenseMetrics,
        minute,
        type: "penalty",
        context,
        rng,
        events,
        recordEvents,
        allowCorner: false,
      });
      return true;
    }
    if (rng.bool(0.22)) {
      takeShot({
        attacking,
        defending,
        attackMetrics,
        defenseMetrics,
        minute,
        type: "freeKick",
        context,
        rng,
        events,
        recordEvents,
      });
      return true;
    }
  }

  if (stage === "progression" && rng.bool(0.07)) {
    takeShot({
      attacking,
      defending,
      attackMetrics,
      defenseMetrics,
      minute,
      type: "freeKick",
      context,
      rng,
      events,
      recordEvents,
    });
    return true;
  }
  return true;
}

function maybeScheduledSubstitution(runtime, minute, context, events, recordEvents) {
  const coach = { ...DEFAULT_COACH, ...runtime.team.coach };
  const earlyShift = (coach.substitutions - 50) * 0.06;
  const schedule = [62 - earlyShift, 72 - earlyShift, 81 - earlyShift];
  if (runtime.substitutionIndex >= schedule.length) return;
  if (minute < schedule[runtime.substitutionIndex]) return;
  runtime.substitutionIndex += 1;
  if (runtime.stats.substitutions >= 5 || runtime.bench.length === 0) return;

  const candidates = activePlayers(runtime).filter((player) => player.role !== "GK");
  const outgoing = candidates
    .filter((player) => runtime.bench.some((bench) => roleGroup(bench.role) === roleGroup(player.role)))
    .sort((left, right) => {
      const leftEnergy = attribute(left, "stamina") + (left.state?.fitness ?? 100) * 0.45;
      const rightEnergy = attribute(right, "stamina") + (right.state?.fitness ?? 100) * 0.45;
      return leftEnergy - rightEnergy;
    })[0];
  if (!outgoing) return;

  const group = roleGroup(outgoing.role);
  const replacementIndex = runtime.bench
    .map((player, index) => ({ player, index }))
    .filter((entry) => roleGroup(entry.player.role) === group)
    .sort(
      (left, right) =>
        attribute(right.player, "stamina") + attribute(right.player, "workRate") -
        attribute(left.player, "stamina") - attribute(left.player, "workRate"),
    )[0]?.index;
  if (replacementIndex === undefined) return;
  const lineupIndex = runtime.lineup.findIndex((player) => player.id === outgoing.id);
  const [replacement] = runtime.bench.splice(replacementIndex, 1);
  runtime.lineup[lineupIndex] = replacement;
  runtime.stats.substitutions += 1;
  touchRuntime(runtime);
  recordEvent(events, recordEvents, {
    minute: Math.ceil(minute),
    type: "substitution",
    team: runtime.team.name,
    playerOut: outgoing.name,
    playerIn: replacement.name,
    reason: "tactical",
  });
}

function simulatePossession({
  attacking,
  defending,
  minute,
  context,
  rng,
  events,
  recordEvents,
}) {
  attacking.stats.possessionSequences += 1;
  const attackMetrics = deriveTeamMetrics(attacking, minute, context);
  const defenseMetrics = deriveTeamMetrics(defending, minute, context);
  const attackTactics = tacticsFor(attacking);
  const defenseTactics = tacticsFor(defending);
  const attackBehavior = matchBehavior(attacking, defending, minute, context);
  const defenseBehavior = matchBehavior(defending, attacking, minute, context);

  const weatherPassPenalty =
    context.weather.precipitation / 380 + context.weather.wind / 520;
  const extremeTempoPenalty = Math.abs(attackTactics.tempo - 52) / 520;
  const directEscape = (attackTactics.directness - 50) / 420;
  const buildProbability = clamp(
    logistic(
      logit(0.835) +
        (attackMetrics.buildUp - defenseMetrics.press) / 23 +
        directEscape -
        (defenseTactics.pressing - 50) / 260 -
        weatherPassPenalty -
        extremeTempoPenalty,
    ),
    0.48,
    0.96,
  );
  if (!rng.bool(buildProbability)) {
    handleFoul({
      stage: "buildUp",
      attacking,
      defending,
      attackMetrics,
      defenseMetrics,
      minute,
      context,
      rng,
      events,
      recordEvents,
    });
    return;
  }

  const widthMatchup =
    (attackTactics.width - 50) / 600 -
    (defenseTactics.width - 50) / 900;
  const progressProbability = clamp(
    logistic(
      logit(0.555) +
        (attackMetrics.progression - defenseMetrics.midfieldDefense) / 21 +
        (attackMetrics.pressResistance - defenseMetrics.press) / 55 +
        widthMatchup +
        attackBehavior.control / 45,
    ),
    0.25,
    0.84,
  );
  if (!rng.bool(progressProbability)) {
    handleFoul({
      stage: "progression",
      attacking,
      defending,
      attackMetrics,
      defenseMetrics,
      minute,
      context,
      rng,
      events,
      recordEvents,
    });
    return;
  }

  const lineRisk =
    (defenseTactics.defensiveLine - 50) / 650 +
    (defenseTactics.risk - 50) / 850;
  const createProbability = clamp(
    logistic(
      logit(0.295) +
        (attackMetrics.chanceCreation - defenseMetrics.defending) / 20 +
        (attackTactics.risk - 50) / 300 +
        attackBehavior.attack / 34 -
        defenseBehavior.defense / 42 +
        lineRisk,
    ),
    0.1,
    0.62,
  );
  if (!rng.bool(createProbability)) {
    handleFoul({
      stage: "finalThird",
      attacking,
      defending,
      attackMetrics,
      defenseMetrics,
      minute,
      context,
      rng,
      events,
      recordEvents,
    });
    return;
  }

  takeShot({
    attacking,
    defending,
    attackMetrics,
    defenseMetrics,
    minute,
    type: chooseShotType(attacking, defending, rng),
    context,
    rng,
    events,
    recordEvents,
  });
}

function possessionProbability(home, away, minute, context) {
  const homeMetrics = deriveTeamMetrics(home, minute, context);
  const awayMetrics = deriveTeamMetrics(away, minute, context);
  const homeBehavior = matchBehavior(home, away, minute, context);
  const awayBehavior = matchBehavior(away, home, minute, context);
  const refereeHomeBias = (context.referee.homeBias - 50) * 0.012;
  const edge =
    homeMetrics.midfieldControl -
    awayMetrics.midfieldControl +
    context.homeAdvantage +
    refereeHomeBias +
    homeBehavior.control -
    awayBehavior.control;
  return clamp(logistic(edge / 17), 0.27, 0.73);
}

function publicStats(runtime, totalPossessions) {
  return {
    goals: runtime.stats.goals,
    xg: Number(runtime.stats.xg.toFixed(3)),
    shots: runtime.stats.shots,
    shotsOnTarget: runtime.stats.shotsOnTarget,
    possession: Number(
      ((runtime.stats.possessionSequences / Math.max(1, totalPossessions)) * 100).toFixed(1),
    ),
    fouls: runtime.stats.fouls,
    yellowCards: runtime.stats.yellows,
    redCards: runtime.stats.reds,
    corners: runtime.stats.corners,
    substitutions: runtime.stats.substitutions,
    injuries: runtime.stats.injuries,
  };
}

export function simulateMatch(homeTeam, awayTeam, options = {}) {
  const context = mergeContext(options.context);
  const rng = new Random(options.seed ?? Date.now());
  const recordEvents = options.recordEvents ?? true;
  const events = [];
  const home = makeRuntime(homeTeam, "home");
  const away = makeRuntime(awayTeam, "away");
  const averageTempo =
    (tacticsFor(home).tempo + tacticsFor(away).tempo) / 2;
  const possessionCount = Math.max(
    80,
    Math.round(
      context.basePossessions *
        (0.84 + averageTempo / 310) *
        (1 - (tacticsFor(home).timeWasting + tacticsFor(away).timeWasting) / 1600) +
        rng.normal(0, 5),
    ),
  );
  const stoppage = clamp(
    2 + rng.normal(0, 1.1) + (home.stats.goals + away.stats.goals) * 0.18,
    1,
    7,
  );
  const totalMinutes = context.minutes + stoppage;

  for (let index = 0; index < possessionCount; index += 1) {
    const minute = ((index + rng.range(0.15, 0.85)) / possessionCount) * totalMinutes;
    maybeScheduledSubstitution(home, minute, context, events, recordEvents);
    maybeScheduledSubstitution(away, minute, context, events, recordEvents);
    const homeHasBall = rng.bool(possessionProbability(home, away, minute, context));
    simulatePossession({
      attacking: homeHasBall ? home : away,
      defending: homeHasBall ? away : home,
      minute,
      context,
      rng,
      events,
      recordEvents,
    });
  }

  const totalPossessions =
    home.stats.possessionSequences + away.stats.possessionSequences;
  return {
    seed: options.seed ?? null,
    homeTeam: home.team.name,
    awayTeam: away.team.name,
    score: { home: home.stats.goals, away: away.stats.goals },
    outcome:
      home.stats.goals > away.stats.goals
        ? "home"
        : home.stats.goals < away.stats.goals
          ? "away"
          : "draw",
    minutes: Math.round(totalMinutes),
    stats: {
      home: publicStats(home, totalPossessions),
      away: publicStats(away, totalPossessions),
    },
    events,
  };
}

export function simulateMany(homeTeam, awayTeam, options = {}) {
  const matches = options.matches ?? 1000;
  const seed = options.seed ?? "batch";
  const totals = {
    homeWins: 0,
    draws: 0,
    awayWins: 0,
    homeGoals: 0,
    awayGoals: 0,
    homeXg: 0,
    awayXg: 0,
    homeShots: 0,
    awayShots: 0,
    homeCards: 0,
    awayCards: 0,
  };
  const scorelines = new Map();

  for (let index = 0; index < matches; index += 1) {
    const result = simulateMatch(homeTeam, awayTeam, {
      ...options,
      seed: seed + ":" + index,
      recordEvents: false,
    });
    if (result.outcome === "home") totals.homeWins += 1;
    else if (result.outcome === "away") totals.awayWins += 1;
    else totals.draws += 1;
    totals.homeGoals += result.score.home;
    totals.awayGoals += result.score.away;
    totals.homeXg += result.stats.home.xg;
    totals.awayXg += result.stats.away.xg;
    totals.homeShots += result.stats.home.shots;
    totals.awayShots += result.stats.away.shots;
    totals.homeCards += result.stats.home.yellowCards + result.stats.home.redCards;
    totals.awayCards += result.stats.away.yellowCards + result.stats.away.redCards;
    const key = result.score.home + "-" + result.score.away;
    scorelines.set(key, (scorelines.get(key) ?? 0) + 1);
  }

  const probability = (count) => Number((count / matches).toFixed(4));
  const mean = (total) => Number((total / matches).toFixed(3));
  return {
    matches,
    teams: { home: homeTeam.name, away: awayTeam.name },
    probabilities: {
      homeWin: probability(totals.homeWins),
      draw: probability(totals.draws),
      awayWin: probability(totals.awayWins),
    },
    averages: {
      homeGoals: mean(totals.homeGoals),
      awayGoals: mean(totals.awayGoals),
      totalGoals: mean(totals.homeGoals + totals.awayGoals),
      homeXg: mean(totals.homeXg),
      awayXg: mean(totals.awayXg),
      homeShots: mean(totals.homeShots),
      awayShots: mean(totals.awayShots),
      homeCards: mean(totals.homeCards),
      awayCards: mean(totals.awayCards),
    },
    commonScorelines: [...scorelines.entries()]
      .sort((left, right) => right[1] - left[1])
      .slice(0, 10)
      .map(([score, count]) => ({ score, probability: probability(count) })),
  };
}
