import {
  FORMATIONS,
  ROLE_LABELS,
  TACTICS,
  clamp,
  createMatch,
  createRng,
  generateDraftChoices,
  generateOpponent,
  generateOpponentSquad,
  pickWeather,
  playerOverall,
  randomItem,
  resolvePenaltyShootout,
  simulateMinute,
  teamRatings,
  traitFitsRole,
  traitGrade,
} from "/game/core.js";

const STORAGE_KEY = "football_test1_demo_v1";
const DRAFT_ROLES = ["GK", "DEF", "MID", "MID", "ATT"];
const screen = document.querySelector("#game-screen");
const modalBackdrop = document.querySelector("#modal-backdrop");
const modal = document.querySelector("#game-modal");
const runStatus = document.querySelector("#run-status");
const toastElement = document.querySelector("#toast");

let catalog = [];
let run = null;
let draft = null;
let runtime = null;
let toastTimer = null;

function escapeHtml(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function showToast(message) {
  toastElement.textContent = message;
  toastElement.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toastElement.classList.remove("show"), 1900);
}

function loadSavedRun() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return saved?.version === 1 || saved?.version === 2 ? normalizeRun(saved) : null;
  } catch {
    return null;
  }
}

function normalizeRun(value) {
  const next = value;
  next.version = 2;
  next.inventory = Array.isArray(next.inventory) ? next.inventory : [];
  next.players = Array.isArray(next.players) ? next.players : [];
  const playerIds = new Set(next.players.map((player) => player.id));
  const existingLineup = Array.isArray(next.lineupIds) ? next.lineupIds : [];
  next.lineupIds = [...new Set(existingLineup.filter((id) => playerIds.has(id)))].slice(0, 5);
  for (const player of next.players) {
    if (next.lineupIds.length >= 5) break;
    if (!next.lineupIds.includes(player.id)) next.lineupIds.push(player.id);
  }
  return next;
}

function getStarters() {
  if (!run) return [];
  normalizeRun(run);
  return run.lineupIds.map((id) => run.players.find((player) => player.id === id)).filter(Boolean);
}

function getBench() {
  const starters = new Set(run?.lineupIds ?? []);
  return (run?.players ?? []).filter((player) => !starters.has(player.id));
}

function traitSlotLimit() {
  return run.stage >= 31 ? 3 : 2;
}

function saveRun() {
  if (!run) return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(run));
  updateHeader();
  const label = document.querySelector("#save-label");
  if (label) {
    label.textContent = "已保存";
    setTimeout(() => { if (label) label.textContent = "本地存档"; }, 900);
  }
}

function updateHeader() {
  runStatus.hidden = !run;
  if (!run) return;
  document.querySelector("#status-stage").textContent = `${String(run.stage).padStart(2, "0")} / 50`;
  document.querySelector("#status-gold").textContent = `${run.gold} G`;
}

function makeNewRun() {
  return {
    version: 2,
    name: "社区梦想队",
    stage: 1,
    gold: 0,
    players: [],
    lineupIds: [],
    inventory: [],
    tactic: "balanced",
    formation: "121",
    opponent: null,
    history: [],
    createdAt: new Date().toISOString(),
  };
}

function getTrait(id) {
  return catalog.find((trait) => trait.id === id);
}

async function loadCatalog() {
  try {
    const response = await fetch("/api/state", { cache: "no-store" });
    if (!response.ok) throw new Error("特性卡接口不可用");
    const payload = await response.json();
    catalog = payload.state?.traitCards ?? [];
  } catch (error) {
    catalog = [];
    showToast("未读取到开发卡池，球员将暂时没有先天特性");
    console.warn(error);
  }
}

function stopRuntime() {
  for (const timer of runtime?.visualTimers ?? []) clearTimeout(timer);
  if (runtime?.animationFrame) cancelAnimationFrame(runtime.animationFrame);
  runtime = null;
}

function renderWelcome() {
  stopRuntime();
  run = null;
  updateHeader();
  const saved = loadSavedRun();
  screen.innerHTML = `
    <section class="hero">
      <div class="hero-copy">
        <p class="kicker">FROM THE COMMUNITY TO THE WORLD</p>
        <h1 class="display-title">从野球场<br /><span class="outline">到世界之巅</span></h1>
        <p class="lede">挑出五名没人认识的球员，用奇怪但有效的特性组建球队。五十场比赛之后，看看谁还敢叫你“社区临时教练”。</p>
        <div class="button-row">
          <button class="primary-button" id="new-run">开始新征程</button>
          ${saved ? `<button class="secondary-button" id="continue-run">继续第 ${saved.stage} 关</button>` : ""}
          <a class="text-button" href="/" style="text-decoration:none">进入开发者后台</a>
        </div>
      </div>
      <div class="hero-art" aria-hidden="true">
        <div class="hero-number">50</div>
        <div class="hero-card">
          <div class="shirt">5</div>
          <div class="hero-card-label"><span><strong>草根首发</strong><small>STARTING FIVE</small></span><b>?</b></div>
        </div>
      </div>
    </section>`;
  document.querySelector("#new-run").addEventListener("click", beginNewRun);
  document.querySelector("#continue-run")?.addEventListener("click", () => {
    run = saved;
    prepareOpponent();
    updateHeader();
    renderHub();
  });
}

function beginNewRun() {
  if (loadSavedRun()) {
    openModal(`
      <p class="kicker">NEW JOURNEY</p>
      <h2>覆盖旧征程？</h2>
      <p>新的五人名单会替换当前本地存档。开发者后台的卡牌与参数不会受到影响。</p>
      <div class="button-row">
        <button class="primary-button" id="confirm-new">确定，重新选人</button>
        <button class="secondary-button" data-close-modal>返回</button>
      </div>`, () => document.querySelector("#confirm-new").addEventListener("click", () => {
        closeModal();
        startDraft();
      }));
  } else {
    startDraft();
  }
}

function startDraft() {
  run = makeNewRun();
  draft = { index: 0, choices: [], selected: null, rng: createRng(`draft-${Date.now()}`) };
  updateHeader();
  makeDraftChoices();
  renderDraft();
}

function makeDraftChoices() {
  const role = DRAFT_ROLES[draft.index];
  draft.choices = generateDraftChoices(role, catalog, draft.rng);
  draft.selected = null;
}

function statBar(label, value) {
  return `<div class="stat-row"><span>${label}</span><div class="stat-line"><i style="width:${value}%"></i></div><b>${value}</b></div>`;
}

function renderDraftCard(player, index) {
  const trait = getTrait(player.traits[0]?.id);
  return `
    <button class="player-card ${draft.selected === index ? "selected" : ""}" data-draft-choice="${index}" data-number="${index + 1}">
      <span class="player-top"><span class="role-chip">${ROLE_LABELS[player.role]}</span><span class="grade-chip">先天 ${traitGrade(trait?.rarity)}</span></span>
      <h2 class="player-name">${escapeHtml(player.name)}</h2>
      <span class="player-sub">${player.attributes.height} CM · 副位置 ${ROLE_LABELS[player.secondaryRole] ?? "无"}</span>
      <span class="overall"><b>${playerOverall(player)}</b><small>综合评估</small></span>
      <div class="stat-bars">
        ${statBar("进攻", player.attributes.attack)}
        ${statBar("传球", player.attributes.passing)}
        ${statBar("防守", player.attributes.defense)}
        ${statBar(player.role === "GK" ? "守门" : "速度", player.role === "GK" ? player.attributes.goalkeeping : player.attributes.pace)}
      </div>
      <div class="trait-ribbon"><small>锁定先天特性</small><strong>${escapeHtml(trait?.name ?? "朴实无华")}</strong><p>${escapeHtml(trait?.summary ?? "没有读取到特性卡数据。")}</p></div>
    </button>`;
}

function renderDraft() {
  const role = DRAFT_ROLES[draft.index];
  screen.innerHTML = `
    <section>
      <header class="screen-head">
        <div><p class="kicker">ROOKIE DRAFT · ${draft.index + 1}/5</p><h1>选择你的${ROLE_LABELS[role]}</h1><p>三选一。数值、性格小癖好与先天特性都会跟着他走完整段征程。</p></div>
        <div class="draft-progress">${DRAFT_ROLES.map((_, index) => `<i class="${index < draft.index ? "done" : index === draft.index ? "current" : ""}"></i>`).join("")}</div>
      </header>
      <div class="card-grid">${draft.choices.map(renderDraftCard).join("")}</div>
      <div class="draft-action">
        <span class="picked-list">已签下：${run.players.length ? run.players.map((player) => `<b>${escapeHtml(player.name)}</b>`).join(" · ") : "还没有人来报到"}</span>
        <button class="primary-button" id="confirm-draft" ${draft.selected === null ? "disabled" : ""}>签下这名球员</button>
      </div>
    </section>`;
  document.querySelectorAll("[data-draft-choice]").forEach((card) => card.addEventListener("click", () => {
    draft.selected = Number(card.dataset.draftChoice);
    renderDraft();
  }));
  document.querySelector("#confirm-draft").addEventListener("click", confirmDraftChoice);
}

function confirmDraftChoice() {
  if (draft.selected === null) return;
  run.players.push(structuredClone(draft.choices[draft.selected]));
  draft.index += 1;
  if (draft.index >= DRAFT_ROLES.length) {
    run.lineupIds = run.players.map((player) => player.id);
    prepareOpponent();
    saveRun();
    draft = null;
    renderHub();
    showToast("五人到齐。社区梦想队正式成立！");
    return;
  }
  makeDraftChoices();
  renderDraft();
}

function tierName(stage) {
  return ["社区赛场", "省级联赛", "全国大赛", "洲际赛场", "国际舞台"][Math.min(4, Math.floor((stage - 1) / 10))];
}

function prepareOpponent(force = false) {
  if (!run.opponent || run.opponent.stage !== run.stage || !Array.isArray(run.opponent.squad) || force) {
    const rng = createRng(`opponent-${run.stage}-${run.history.length}-${Date.now()}`);
    run.opponent = { ...generateOpponent(run.stage, rng), stage: run.stage };
    run.opponent.squad = generateOpponentSquad(run.opponent, rng, 3);
    saveRun();
  }
}

function tacticsBoardPositions(formationKey) {
  return ({
    "121": [[50,88],[50,69],[29,45],[71,45],[50,17]],
    "112": [[50,88],[50,69],[50,46],[29,18],[71,18]],
    "211": [[50,88],[29,68],[71,68],[50,43],[50,16]],
  })[formationKey] ?? [[50,88],[50,69],[29,45],[71,45],[50,17]];
}

function tacticsMagnet(player, slotIndex = null, requiredRole = null) {
  const fit = requiredRole ? (player.role === requiredRole ? "primary" : player.secondaryRole === requiredRole ? "secondary" : "out") : "bench";
  const fitLabel = fit === "primary" ? "主位置" : fit === "secondary" ? "副位置" : fit === "out" ? "客串" : "替补";
  return `<button type="button" class="tactics-magnet fit-${fit}" data-board-player="${player.id}" ${slotIndex === null ? "" : `data-board-slot="${slotIndex}"`} aria-label="${escapeHtml(player.name)}，${ROLE_LABELS[player.role]}，${fitLabel}，拖动以调整阵容" title="${escapeHtml(player.name)} · ${ROLE_LABELS[player.role]} · ${fitLabel} · 综合 ${playerOverall(player)}">
    <span class="magnet-number">${slotIndex === null ? "B" : slotIndex + 1}</span><span class="magnet-copy"><b>${escapeHtml(player.name)}</b><small>${ROLE_LABELS[player.role]} · ${fitLabel} · ${playerOverall(player)}</small></span><i>${player.attributes.fitness}</i>
  </button>`;
}

let selectedBoardPlayerId = null;
let suppressBoardClick = false;

function applyTacticsBoardMove(sourceId, targetSlot = null, targetPlayerId = null) {
  const sourceSlot = run.lineupIds.indexOf(sourceId);
  const resolvedTargetSlot = targetSlot ?? run.lineupIds.indexOf(targetPlayerId);
  if (resolvedTargetSlot >= 0) {
    if (sourceSlot >= 0) {
      if (sourceSlot === resolvedTargetSlot) return false;
      [run.lineupIds[sourceSlot], run.lineupIds[resolvedTargetSlot]] = [run.lineupIds[resolvedTargetSlot], run.lineupIds[sourceSlot]];
    } else {
      run.lineupIds[resolvedTargetSlot] = sourceId;
    }
  } else if (sourceSlot >= 0 && targetPlayerId && !run.lineupIds.includes(targetPlayerId)) {
    run.lineupIds[sourceSlot] = targetPlayerId;
  } else {
    return false;
  }
  saveRun();
  selectedBoardPlayerId = null;
  renderHub();
  showToast("战术板已更新");
  return true;
}

function bindTacticsBoard() {
  document.querySelectorAll("[data-board-player]").forEach((magnet) => {
    magnet.addEventListener("click", () => {
      if (suppressBoardClick) return;
      const playerId = magnet.dataset.boardPlayer;
      if (!selectedBoardPlayerId) {
        selectedBoardPlayerId = playerId;
        document.querySelectorAll("[data-board-player]").forEach((item) => item.classList.toggle("selected", item.dataset.boardPlayer === playerId));
        showToast("已拿起球员磁贴，再点一名球员即可互换");
        return;
      }
      if (selectedBoardPlayerId === playerId) {
        selectedBoardPlayerId = null;
        magnet.classList.remove("selected");
        return;
      }
      applyTacticsBoardMove(selectedBoardPlayerId, null, playerId);
    });
    magnet.addEventListener("keydown", (event) => {
      if (event.key === "Enter" && event.altKey) openLineupEditor();
    });
    magnet.addEventListener("pointerdown", (event) => {
      if (event.button !== undefined && event.button !== 0) return;
      const sourceId = magnet.dataset.boardPlayer;
      const startX = event.clientX;
      const startY = event.clientY;
      let ghost = null;
      let moved = false;
      const move = (moveEvent) => {
        const distance = Math.hypot(moveEvent.clientX - startX, moveEvent.clientY - startY);
        if (distance < 7 && !moved) return;
        moveEvent.preventDefault();
        moved = true;
        if (!ghost) {
          ghost = magnet.cloneNode(true);
          ghost.classList.add("drag-ghost");
          ghost.removeAttribute("style");
          document.body.appendChild(ghost);
          magnet.classList.add("drag-source");
        }
        ghost.style.left = `${moveEvent.clientX}px`;
        ghost.style.top = `${moveEvent.clientY}px`;
        document.querySelectorAll("[data-drop-slot], .bench-magnets").forEach((target) => target.classList.remove("drag-over"));
        document.elementFromPoint(moveEvent.clientX, moveEvent.clientY)?.closest("[data-drop-slot], .bench-magnets")?.classList.add("drag-over");
      };
      const up = (upEvent) => {
        window.removeEventListener("pointermove", move);
        window.removeEventListener("pointerup", up);
        window.removeEventListener("pointercancel", up);
        magnet.classList.remove("drag-source");
        ghost?.remove();
        document.querySelectorAll(".drag-over").forEach((target) => target.classList.remove("drag-over"));
        if (!moved) return;
        suppressBoardClick = true;
        setTimeout(() => { suppressBoardClick = false; }, 80);
        const target = document.elementFromPoint(upEvent.clientX, upEvent.clientY);
        const targetMagnet = target?.closest("[data-board-player]");
        const targetSlotElement = target?.closest("[data-drop-slot]");
        const targetSlot = targetSlotElement ? Number(targetSlotElement.dataset.dropSlot) : null;
        if (!applyTacticsBoardMove(sourceId, Number.isInteger(targetSlot) ? targetSlot : null, targetMagnet?.dataset.boardPlayer ?? null)) {
          showToast("把磁贴拖到场上位置或另一名球员身上");
        }
      };
      window.addEventListener("pointermove", move, { passive: false });
      window.addEventListener("pointerup", up, { once: true });
      window.addEventListener("pointercancel", up, { once: true });
    });
  });
}

function renderHub() {
  stopRuntime();
  selectedBoardPlayerId = null;
  prepareOpponent();
  updateHeader();
  const starters = getStarters();
  const bench = getBench();
  const ratings = teamRatings(starters, run.tactic, catalog, run.formation);
  const slots = FORMATIONS[run.formation].slots;
  const boardPositions = tacticsBoardPositions(run.formation);
  screen.innerHTML = `
    <section>
      <header class="screen-head">
        <div><p class="kicker">${tierName(run.stage)} · MATCH ${String(run.stage).padStart(2, "0")}</p><h1>比赛日，更衣室</h1><p>检查阵容与战术。错误位置会让球员只能发挥 72% 的能力。</p></div>
        <div class="button-row"><button class="secondary-button" id="open-club">球队与背包</button><button class="secondary-button" id="open-shop">商店</button><button class="secondary-button" id="back-title">返回标题</button></div>
      </header>
      <div class="hub-layout">
        <section class="panel tactics-panel">
          <header class="panel-heading"><div><h2>比赛战术板</h2><small>拖动磁贴调整首发和站位</small></div><span>综合 ${Math.round((ratings.attack + ratings.midfield + ratings.defense + ratings.goalkeeping) / 4)}</span></header>
          <div class="tactics-board-wrap">
            <div class="tactics-board" aria-label="可拖动的首发战术板">
              <div class="chalk-pitch" aria-hidden="true"><i class="chalk-half"></i><i class="chalk-circle"></i><i class="chalk-box top"></i><i class="chalk-box bottom"></i></div>
              <span class="board-direction">进攻方向 ↑</span>
              ${starters.map((player, index) => `<div class="board-drop-slot" data-drop-slot="${index}" style="left:${boardPositions[index][0]}%;top:${boardPositions[index][1]}%"><span class="slot-role">${ROLE_LABELS[slots[index]]}</span>${tacticsMagnet(player, index, slots[index])}</div>`).join("")}
            </div>
            <div class="bench-board"><header><b>替补长凳</b><small>拖到场上磁贴即可换人</small></header><div class="bench-magnets">${bench.length ? bench.map((player) => tacticsMagnet(player)).join("") : `<p>替补席还是空的，赢下第 3 关后会获得第一位替补球员。</p>`}</div></div>
          </div>
          <div class="lineup-footer"><span>拖动或依次点击两名球员进行互换</span><button class="secondary-button" id="edit-lineup">精确调整</button></div>
        </section>
        <aside class="side-stack">
          <section class="panel stage-card" data-stage="${run.stage}">
            <p class="kicker">NEXT OPPONENT</p><h3>${escapeHtml(run.opponent.name)}</h3><p>${tierName(run.stage)}第 ${((run.stage - 1) % 10) + 1} 轮</p>
            <div class="opponent-line"><span><small>对手评级</small><b>${run.opponent.rating}</b></span><span style="text-align:right"><small>预计战术</small><b>${TACTICS[run.opponent.tactic]?.name}</b></span></div>
          </section>
          <section class="panel control-card">
            <label class="field-label" for="formation">场上结构</label>
            <select class="select-control" id="formation">${Object.entries(FORMATIONS).map(([key, item]) => `<option value="${key}" ${run.formation === key ? "selected" : ""}>${item.name}</option>`).join("")}</select>
            <label class="field-label" for="tactic">比赛策略</label>
            <select class="select-control" id="tactic">${Object.entries(TACTICS).map(([key, item]) => `<option value="${key}" ${run.tactic === key ? "selected" : ""}>${item.name}</option>`).join("")}</select>
            <p class="tactic-note" id="tactic-note">${TACTICS[run.tactic].note}</p>
            <button class="primary-button wide" id="start-match" ${starters.length !== 5 ? "disabled" : ""}>进入球场</button>
          </section>
        </aside>
      </div>
    </section>`;
  document.querySelector("#back-title").addEventListener("click", renderWelcome);
  document.querySelector("#open-club").addEventListener("click", () => renderClub("players"));
  document.querySelector("#open-shop").addEventListener("click", renderShop);
  document.querySelector("#edit-lineup").addEventListener("click", openLineupEditor);
  document.querySelector("#formation").addEventListener("change", (event) => { run.formation = event.target.value; saveRun(); renderHub(); });
  document.querySelector("#tactic").addEventListener("change", (event) => {
    run.tactic = event.target.value;
    saveRun();
    document.querySelector("#tactic-note").textContent = TACTICS[run.tactic].note;
  });
  document.querySelector("#start-match").addEventListener("click", startMatch);
  bindTacticsBoard();
}

function openLineupEditor() {
  const slots = FORMATIONS[run.formation].slots;
  openModal(`
    <div class="lineup-editor">
      <p class="kicker">STARTING FIVE</p><h2>调整首发五人</h2>
      <p>每个位置必须选择不同球员。主位置完全发挥，副位置发挥 88%，其他位置发挥 72%。</p>
      <div class="lineup-slot-list">
        ${slots.map((role, index) => `<label class="lineup-slot"><span><b>${index + 1}</b><small>${ROLE_LABELS[role]}</small></span><select class="select-control" data-lineup-slot="${index}">${run.players.map((player) => `<option value="${player.id}" ${run.lineupIds[index] === player.id ? "selected" : ""}>${escapeHtml(player.name)} · ${ROLE_LABELS[player.role]} · ${player.role === role ? "主位置" : player.secondaryRole === role ? "副位置" : "客串"} · ${playerOverall(player)}</option>`).join("")}</select></label>`).join("")}
      </div>
      <div class="button-row"><button class="primary-button" id="save-lineup">保存首发</button><button class="secondary-button" data-close-modal>取消</button></div>
    </div>`, () => document.querySelector("#save-lineup").addEventListener("click", () => {
      const ids = [...document.querySelectorAll("[data-lineup-slot]")].map((select) => select.value);
      if (new Set(ids).size !== 5) return showToast("同一名球员不能占据两个首发位置");
      run.lineupIds = ids;
      saveRun();
      closeModal();
      renderHub();
      showToast("首发名单已更新");
    }));
}

function renderClub(activeTab = "players") {
  stopRuntime();
  updateHeader();
  const inventoryCounts = run.inventory.reduce((map, id) => map.set(id, (map.get(id) ?? 0) + 1), new Map());
  const inventoryCards = [...inventoryCounts.entries()].map(([id, count]) => ({ trait: getTrait(id), count })).filter((item) => item.trait);
  const starters = new Set(run.lineupIds);
  screen.innerHTML = `
    <section>
      <header class="screen-head"><div><p class="kicker">CLUB MANAGEMENT</p><h1>球队与背包</h1><p>管理全部球员、首发名单与可装备的特性卡。</p></div><button class="secondary-button" id="club-back">返回更衣室</button></header>
      <div class="club-tabs"><button class="club-tab ${activeTab === "players" ? "active" : ""}" data-club-tab="players">球员名单 <b>${run.players.length}</b></button><button class="club-tab ${activeTab === "traits" ? "active" : ""}" data-club-tab="traits">特性背包 <b>${run.inventory.length}</b></button></div>
      ${activeTab === "players" ? `
        <div class="club-actions"><span>当前首发 ${run.lineupIds.length}/5</span><button class="primary-button" id="club-lineup">调整首发</button></div>
        <div class="club-player-grid">${run.players.map((player) => {
          const equipped = player.traits.map((entry) => ({ ...entry, trait: getTrait(entry.id) })).filter((entry) => entry.trait);
          return `<article class="club-player-card ${starters.has(player.id) ? "starter" : ""}">
            <div class="club-player-head"><span class="role-chip">${ROLE_LABELS[player.role]}</span><span>${starters.has(player.id) ? "首发" : "替补"}</span></div>
            <h2>${escapeHtml(player.name)} <b>${playerOverall(player)}</b></h2><p>${player.attributes.height} CM · 副位置 ${ROLE_LABELS[player.secondaryRole] ?? "无"} · 体能 ${player.attributes.fitness}</p>
            <div class="equipped-traits">${equipped.map((entry) => `<span class="${entry.innate ? "innate" : ""}">${entry.innate ? "锁" : traitGrade(entry.trait.rarity)} · ${escapeHtml(entry.trait.name)}</span>`).join("")}</div>
            <div class="button-row"><button class="secondary-button" data-manage-traits="${player.id}">修改特性</button><button class="text-button" data-club-rename="${player.id}">改名</button></div>
          </article>`;
        }).join("")}</div>` : `
        <div class="inventory-head"><span>背包中的卡可以装备给任意球员；不适配位置时效果较低。</span><b>${run.inventory.length} 张</b></div>
        ${inventoryCards.length ? `<div class="inventory-grid">${inventoryCards.map(({ trait, count }) => `<article class="inventory-card grade-${traitGrade(trait.rarity).toLowerCase()}"><div><span class="inventory-grade">${traitGrade(trait.rarity)}</span><small>× ${count}</small></div><h3>${escapeHtml(trait.name)}</h3><p>${escapeHtml(trait.summary)}</p><label class="field-label">装备给球员</label><select class="select-control" data-equip-target="${trait.id}">${run.players.map((player) => `<option value="${player.id}">${escapeHtml(player.name)} · ${ROLE_LABELS[player.role]}${traitFitsRole(trait, player.role) ? " · 适配" : " · 低收益"}</option>`).join("")}</select><button class="primary-button wide" data-equip-trait="${trait.id}">装备</button></article>`).join("")}</div>` : `<div class="panel empty-club"><h2>背包还是空的</h2><p>比赛奖励和商店购买的卡牌会出现在这里。</p><button class="primary-button" id="empty-shop">去商店看看</button></div>`}
      `}
    </section>`;
  document.querySelector("#club-back").addEventListener("click", renderHub);
  document.querySelectorAll("[data-club-tab]").forEach((button) => button.addEventListener("click", () => renderClub(button.dataset.clubTab)));
  document.querySelector("#club-lineup")?.addEventListener("click", openLineupEditor);
  document.querySelector("#empty-shop")?.addEventListener("click", renderShop);
  document.querySelectorAll("[data-manage-traits]").forEach((button) => button.addEventListener("click", () => openTraitManager(button.dataset.manageTraits)));
  document.querySelectorAll("[data-club-rename]").forEach((button) => button.addEventListener("click", () => openRename(button.dataset.clubRename, () => renderClub("players"))));
  document.querySelectorAll("[data-equip-trait]").forEach((button) => button.addEventListener("click", () => equipInventoryTrait(button.dataset.equipTrait)));
}

function removeOneInventoryCard(traitId) {
  const index = run.inventory.indexOf(traitId);
  if (index >= 0) run.inventory.splice(index, 1);
}

function equipInventoryTrait(traitId) {
  const target = document.querySelector(`[data-equip-target="${traitId}"]`);
  const player = run.players.find((item) => item.id === target?.value);
  if (!player) return;
  if (player.traits.length >= traitSlotLimit()) return showToast("该球员的特性槽位已满，请先替换或卸下后天特性");
  if (player.traits.some((entry) => entry.id === traitId)) return showToast("该球员已经拥有这项特性");
  player.traits.push({ id: traitId, innate: false });
  removeOneInventoryCard(traitId);
  saveRun();
  renderClub("traits");
  showToast(`已装备给 ${player.name}`);
}

function openTraitManager(playerId, preferredTraitId = null) {
  const player = run.players.find((item) => item.id === playerId);
  const entries = player.traits.map((entry, index) => ({ entry, index, trait: getTrait(entry.id) })).filter((item) => item.trait);
  const inventoryIds = [...new Set(run.inventory)].filter((id) => getTrait(id));
  const inventoryOptions = inventoryIds.map((id) => {
    const trait = getTrait(id);
    return `<option value="${id}" ${preferredTraitId === id ? "selected" : ""}>${traitGrade(trait.rarity)} · ${escapeHtml(trait.name)}${traitFitsRole(trait, player.role) ? " · 适配" : " · 低收益"}</option>`;
  }).join("");
  openModal(`
    <p class="kicker">TRAIT LOADOUT</p><h2>${escapeHtml(player.name)}的特性</h2><p>先天特性永久锁定。后天特性可以卸下或直接替换，卸下的卡会返回背包。</p>
    <div class="trait-manager-list">${entries.map(({ entry, index, trait }) => `<div class="trait-equipped-row"><span class="inventory-grade">${entry.innate ? "锁" : traitGrade(trait.rarity)}</span><span><b>${escapeHtml(trait.name)}</b><small>${entry.innate ? "先天特性 · 不可替换" : escapeHtml(trait.summary)}</small></span>${entry.innate ? `<i>固定</i>` : `<div><select class="select-control" data-replace-select="${index}" ${inventoryIds.length ? "" : "disabled"}>${inventoryOptions || `<option>背包无卡</option>`}</select><button class="secondary-button" data-replace-trait="${index}" ${inventoryIds.length ? "" : "disabled"}>替换</button><button class="text-button" data-remove-trait="${index}">卸下</button></div>`}</div>`).join("")}</div>
    ${player.traits.length < traitSlotLimit() ? `<div class="trait-add-row"><select class="select-control" id="add-trait-select" ${inventoryIds.length ? "" : "disabled"}>${inventoryOptions || `<option>背包无卡</option>`}</select><button class="primary-button" id="add-trait" ${inventoryIds.length ? "" : "disabled"}>装备新特性</button></div>` : `<p>当前槽位已满（${player.traits.length}/${traitSlotLimit()}）。</p>`}
    <div class="button-row"><button class="secondary-button" id="close-traits">完成</button></div>`, () => {
      document.querySelector("#close-traits").addEventListener("click", () => { closeModal(); renderClub("players"); });
      document.querySelector("#add-trait")?.addEventListener("click", () => {
        const id = document.querySelector("#add-trait-select").value;
        if (player.traits.some((entry) => entry.id === id)) return showToast("不能重复装备同一特性");
        player.traits.push({ id, innate: false }); removeOneInventoryCard(id); saveRun(); openTraitManager(playerId);
      });
      document.querySelectorAll("[data-remove-trait]").forEach((button) => button.addEventListener("click", () => {
        const index = Number(button.dataset.removeTrait); const [removed] = player.traits.splice(index, 1); run.inventory.push(removed.id); saveRun(); openTraitManager(playerId);
      }));
      document.querySelectorAll("[data-replace-trait]").forEach((button) => button.addEventListener("click", () => {
        const index = Number(button.dataset.replaceTrait);
        const nextId = document.querySelector(`[data-replace-select="${index}"]`).value;
        if (player.traits.some((entry, entryIndex) => entry.id === nextId && entryIndex !== index)) return showToast("不能重复装备同一特性");
        const oldId = player.traits[index].id;
        player.traits[index] = { id: nextId, innate: false };
        removeOneInventoryCard(nextId); run.inventory.push(oldId); saveRun(); openTraitManager(playerId);
      }));
    });
}

function shopPrice(trait) {
  return ({ common: 80, rare: 180, epic: 420, legendary: 900 })[trait.rarity] ?? 100;
}

function featuredShopCards() {
  const rng = createRng(`shop-${run.stage}`);
  const pool = [...catalog];
  for (let index = pool.length - 1; index > 0; index -= 1) {
    const swap = Math.floor(rng() * (index + 1));
    [pool[index], pool[swap]] = [pool[swap], pool[index]];
  }
  return pool.slice(0, 4);
}

function drawShopTrait() {
  const rng = createRng(`shop-draw-${Date.now()}-${run.inventory.length}`);
  const weights = { common: 62, rare: 27, epic: 9, legendary: 2 };
  const total = catalog.reduce((sum, trait) => sum + weights[trait.rarity], 0);
  let roll = rng() * total;
  for (const trait of catalog) {
    roll -= weights[trait.rarity];
    if (roll <= 0) return trait;
  }
  return catalog[0];
}

function renderShop() {
  stopRuntime(); updateHeader();
  run.shopBought ??= {};
  const bought = run.shopBought[run.stage] ?? [];
  const offers = featuredShopCards();
  screen.innerHTML = `<section><header class="screen-head"><div><p class="kicker">COMMUNITY MARKET</p><h1>场边小卖部</h1><p>直接购买特性卡，或者相信球探和抽卡机。</p></div><div class="shop-balance"><small>可用资金</small><b>${run.gold} G</b><button class="secondary-button" id="shop-back">返回更衣室</button></div></header>
    <div class="shop-grid">${offers.map((trait) => { const price = shopPrice(trait); const sold = bought.includes(trait.id); return `<article class="shop-card"><span class="inventory-grade">${traitGrade(trait.rarity)}</span><h2>${escapeHtml(trait.name)}</h2><p>${escapeHtml(trait.summary)}</p><button class="primary-button wide" data-buy-card="${trait.id}" ${sold || run.gold < price ? "disabled" : ""}>${sold ? "已售出" : `${price} G · 购买`}</button></article>`; }).join("")}</div>
    <div class="shop-services"><article class="panel service-card"><p class="kicker">TRAIT DRAW</p><h2>特性盲盒</h2><p>花费 110 G 随机获得一张特性卡，高等级卡依然稀有。</p><button class="primary-button" id="shop-draw" ${run.gold < 110 ? "disabled" : ""}>110 G · 抽一次</button></article><article class="panel service-card"><p class="kicker">PLAYER SCOUT</p><h2>社区球探</h2><p>花费 320 G 招募一名随机位置的新球员，他会进入替补席。</p><button class="primary-button" id="shop-scout" ${run.gold < 320 ? "disabled" : ""}>320 G · 招募</button></article></div>
  </section>`;
  document.querySelector("#shop-back").addEventListener("click", renderHub);
  document.querySelectorAll("[data-buy-card]").forEach((button) => button.addEventListener("click", () => {
    const trait = getTrait(button.dataset.buyCard); const price = shopPrice(trait);
    if (run.gold < price) return; run.gold -= price; run.inventory.push(trait.id); run.shopBought[run.stage] = [...bought, trait.id]; saveRun(); renderShop(); showToast(`${trait.name} 已放入背包`);
  }));
  document.querySelector("#shop-draw").addEventListener("click", () => {
    if (run.gold < 110) return; run.gold -= 110; const trait = drawShopTrait(); run.inventory.push(trait.id); saveRun(); renderShop(); showToast(`抽到了 ${traitGrade(trait.rarity)} 级「${trait.name}」`);
  });
  document.querySelector("#shop-scout").addEventListener("click", () => {
    if (run.gold < 320) return; run.gold -= 320; const rng = createRng(`scout-${Date.now()}`); const role = randomItem(["GK", "DEF", "MID", "ATT"], rng); const player = generateDraftChoices(role, catalog, rng)[0]; run.players.push(player); saveRun(); renderShop(); showToast(`${player.name} 已加入替补席`);
  });
}

function openRename(playerId, afterSave = renderHub) {
  const player = run.players.find((item) => item.id === playerId);
  openModal(`
    <p class="kicker">PLAYER IDENTITY</p><h2>球衣背后写什么？</h2>
    <p>${escapeHtml(player.quirk)}</p>
    <label class="field-label" for="player-name">新名字（队内不可重复）</label>
    <input class="modal-input" id="player-name" maxlength="12" value="${escapeHtml(player.name)}" />
    <div class="button-row" style="margin-top:22px"><button class="primary-button" id="save-name">确认改名</button><button class="secondary-button" data-close-modal>取消</button></div>`,
  () => document.querySelector("#save-name").addEventListener("click", () => {
    const name = document.querySelector("#player-name").value.trim();
    if (!name) return showToast("名字不能为空");
    if (run.players.some((item) => item.id !== player.id && item.name === name)) return showToast("队里已经有人叫这个名字了");
    player.name = name;
    saveRun();
    closeModal();
    afterSave();
  }));
}

function startMatch() {
  const rng = createRng(`match-${run.stage}-${run.history.length}-${Date.now()}`);
  const weather = pickWeather(rng);
  const homeRoster = getStarters();
  const awayRoster = run.opponent.squad.slice(0, 5);
  const match = createMatch(run, run.opponent, { weather, rng, homeRoster, awayRoster });
  runtime = {
    rng,
    match,
    ratings: teamRatings(homeRoster, run.tactic, catalog, run.formation),
    homeBench: getBench(),
    awayBench: run.opponent.squad.slice(5),
    playedIds: new Set(homeRoster.map((player) => player.id)),
    running: true,
    speed: 1,
    targetMinute: 0,
    lastTime: null,
    halftimeDone: false,
    extraAnnounced: false,
    lastMotionMinute: -1,
    tokenPositions: [],
    visualTimers: [],
    eventAnimationUntil: 0,
  };
  renderMatch();
  runtime.animationFrame = requestAnimationFrame(matchLoop);
}

function renderMatch() {
  const match = runtime.match;
  screen.innerHTML = `
    <section class="match-wrap">
      <div class="match-main">
        <header class="scoreboard">
          <span class="team-name">${escapeHtml(run.name)}</span>
          <span class="score-center"><span class="score" id="score">0 — 0</span><span class="clock" id="clock">00:00 · 上半场</span></span>
          <span class="team-name away">${escapeHtml(run.opponent.name)}</span>
        </header>
        <div class="pitch-frame">
          <div class="pitch" id="pitch"><i class="penalty-box left"></i><i class="penalty-box right"></i>${makeTokens()}<i class="ball" id="ball" style="left:50%;top:50%"></i></div>
          <div class="match-flash" id="match-flash">进球！</div>
          <div class="goal-celebration" id="goal-celebration"><span>GOAL</span><strong id="goal-player"></strong><small id="goal-assist"></small><i></i><i></i><i></i><i></i><i></i><i></i></div>
        </div>
        <div class="match-toolbar">
          <div class="button-row"><button class="secondary-button" id="pause-match">暂停与调整</button><span style="color:var(--muted);font-size:13px">标准比赛 3 分钟 · 中场自动暂停</span></div>
          <div class="speed-controls"><button class="speed-button active" data-speed="1">×1</button><button class="speed-button" data-speed="2">×2</button><button class="speed-button" data-speed="4">×4</button></div>
        </div>
        <section class="match-rosters" id="match-rosters">${matchRosterPanel()}</section>
      </div>
      <aside class="match-side">
        <section class="panel weather-card"><span><small>比赛天气</small><b>${match.weather.name}</b></span><span class="weather-code">${match.weather.icon}</span></section>
        <section class="panel stats-card" id="match-stats"></section>
        <section class="panel feed-card"><h3>场边记录</h3><div class="event-feed" id="event-feed"><div class="event empty">双方正在互相观察，顺便确认球门在哪边。</div></div></section>
      </aside>
    </section>`;
  document.querySelector("#pause-match").addEventListener("click", () => pauseMatch(false));
  document.querySelectorAll("[data-speed]").forEach((button) => button.addEventListener("click", () => {
    runtime.speed = Number(button.dataset.speed);
    document.querySelectorAll("[data-speed]").forEach((item) => item.classList.toggle("active", item === button));
  }));
  updateMatchUi();
  moveTokens(true);
}

function makeTokens() {
  return [...runtime.match.homeRoster, ...runtime.match.awayRoster].map((player, index) => `<i class="player-token ${index < 5 ? "home" : "away"}" data-token="${index}" data-player-id="${escapeHtml(player.id)}" title="${escapeHtml(player.name)}">${player.number ?? index % 5 + 1}</i>`).join("");
}

function rosterChips(players, emptyText) {
  return players.length ? players.map((player) => `<span><b>${player.number ?? "·"}</b>${escapeHtml(player.name)}<small>${ROLE_LABELS[player.role]}</small></span>`).join("") : `<em>${emptyText}</em>`;
}

function matchRosterPanel() {
  return `<div class="match-roster-team"><header><b>${escapeHtml(run.name)}</b><small>首发</small></header><div class="roster-chips">${rosterChips(runtime.match.homeRoster, "暂无球员")}</div><footer><small>替补席</small><div class="roster-chips bench">${rosterChips(runtime.homeBench, "无替补")}</div></footer></div><div class="roster-divider">VS</div><div class="match-roster-team away"><header><b>${escapeHtml(run.opponent.name)}</b><small>首发</small></header><div class="roster-chips">${rosterChips(runtime.match.awayRoster, "暂无球员")}</div><footer><small>替补席</small><div class="roster-chips bench">${rosterChips(runtime.awayBench, "无替补")}</div></footer></div>`;
}

function formationPositions(key, home = true) {
  const maps = {
    "121": [[8,50],[31,50],[51,28],[51,72],[75,50]],
    "112": [[8,50],[31,50],[52,50],[75,31],[75,69]],
    "211": [[8,50],[31,31],[31,69],[54,50],[76,50]],
  };
  const positions = maps[key] ?? maps["121"];
  return home ? positions : positions.map(([x,y]) => [100 - x, 100 - y]);
}

function moveTokens(force = false) {
  if (!runtime) return;
  if (!force && performance.now() < runtime.eventAnimationUntil) return;
  const minute = Math.floor(runtime.match.minute);
  if (!force && minute === runtime.lastMotionMinute) return;
  runtime.lastMotionMinute = minute;
  const home = formationPositions(run.formation, true);
  const away = formationPositions("121", false);
  const nextPositions = [];
  [...home, ...away].forEach(([baseX, baseY], index) => {
    const token = document.querySelector(`[data-token="${index}"]`);
    if (!token) return;
    const sentOff = index < 5
      ? index >= 5 - runtime.match.reds.home
      : index >= 10 - runtime.match.reds.away;
    token.style.display = sentOff ? "none" : "grid";
    const wave = Math.sin((minute + index * 3.1) * 0.38);
    const possessionPush = runtime.match.possession.home > 50 ? (index < 5 ? 5 : 3) : (index < 5 ? -3 : -5);
    const x = clamp(baseX + wave * 4 + possessionPush, 5, 95);
    const y = clamp(baseY + Math.cos((minute + index) * .31) * 5, 7, 93);
    nextPositions[index] = [x, y];
    token.style.left = `${x}%`;
    token.style.top = `${y}%`;
  });
  runtime.tokenPositions = nextPositions;
  const ball = document.querySelector("#ball");
  if (ball) {
    const homeHasBall = runtime.rng() * 100 < runtime.match.possession.home;
    const offset = homeHasBall ? 0 : 5;
    const carrierIndex = offset + Math.floor(runtime.rng() * 5);
    const [x, y] = nextPositions[carrierIndex] ?? [50, 50];
    ball.style.transitionDuration = ".7s";
    ball.style.left = `${x + (homeHasBall ? 1.7 : -1.7)}%`;
    ball.style.top = `${y + 1}%`;
  }
}

function scheduleVisual(callback, delay) {
  const timer = setTimeout(callback, delay);
  runtime?.visualTimers.push(timer);
}

function playMatchEvent(event) {
  if (!runtime) return;
  runtime.eventAnimationUntil = performance.now() + 1100;
  const allPlayers = [...runtime.match.homeRoster, ...runtime.match.awayRoster];
  const shooterIndex = allPlayers.findIndex((player) => player.id === event.playerId);
  const assistIndex = allPlayers.findIndex((player) => player.id === event.assistId);
  const attackingHome = event.side === "home";
  const shotX = attackingHome ? 86 : 14;
  const goalX = attackingHome ? 98 : 2;
  const shotY = 38 + runtime.rng() * 24;
  const shooter = document.querySelector(`[data-token="${shooterIndex}"]`);
  const assister = document.querySelector(`[data-token="${assistIndex}"]`);
  const ball = document.querySelector("#ball");
  if (!ball || shooterIndex < 0) return moveTokens(true);
  if (shooter) { shooter.style.left = `${shotX}%`; shooter.style.top = `${shotY}%`; }
  if (assister) { assister.style.left = `${attackingHome ? 67 : 33}%`; assister.style.top = `${shotY > 50 ? 30 : 70}%`; }
  const start = assistIndex >= 0 ? runtime.tokenPositions[assistIndex] : runtime.tokenPositions[shooterIndex];
  if (start) { ball.style.left = `${start[0]}%`; ball.style.top = `${start[1]}%`; }
  ball.style.transitionDuration = ".34s";
  requestAnimationFrame(() => {
    ball.style.left = `${shotX}%`;
    ball.style.top = `${shotY}%`;
  });
  scheduleVisual(() => {
    if (!runtime) return;
    ball.style.transitionDuration = ".42s";
    ball.style.left = `${event.type === "miss" ? goalX : event.type === "save" ? (attackingHome ? 93 : 7) : goalX}%`;
    ball.style.top = `${event.type === "miss" ? (runtime.rng() < .5 ? 15 : 85) : 50}%`;
  }, 350);
  if (event.type === "goal") scheduleVisual(() => showGoalCelebration(event), 650);
}

function showGoalCelebration(event) {
  const celebration = document.querySelector("#goal-celebration");
  const scoreboard = document.querySelector(".scoreboard");
  if (!celebration) return;
  document.querySelector("#goal-player").textContent = event.playerName;
  document.querySelector("#goal-assist").textContent = event.assistName ? `助攻 · ${event.assistName}` : "个人突破 · 无助攻";
  celebration.classList.remove("show");
  void celebration.offsetWidth;
  celebration.classList.add("show");
  scoreboard?.classList.add("goal-pulse");
  scheduleVisual(() => { celebration.classList.remove("show"); scoreboard?.classList.remove("goal-pulse"); moveTokens(true); }, 1500);
}

function matchLoop(timestamp) {
  if (!runtime) return;
  if (runtime.lastTime === null) runtime.lastTime = timestamp;
  const delta = Math.min(0.12, (timestamp - runtime.lastTime) / 1000);
  runtime.lastTime = timestamp;
  if (runtime.running) {
    runtime.targetMinute += delta * 0.5 * runtime.speed;
    const target = Math.floor(runtime.targetMinute);
    while (runtime.match.minute < target) {
      runtime.match.minute += 1;
      const event = simulateMinute(runtime.match, runtime.ratings, runtime.rng);
      if (event) playMatchEvent(event);
      else moveTokens();
      if (runtime.match.minute === 45 && !runtime.halftimeDone) {
        runtime.halftimeDone = true;
        runtime.running = false;
        updateMatchUi();
        pauseMatch(true);
        break;
      }
      if (runtime.match.minute === 90 && !runtime.extraAnnounced) {
        if (runtime.match.homeScore === runtime.match.awayScore) {
          runtime.extraAnnounced = true;
          runtime.match.phase = "extraTime";
          flash("加时赛！");
        } else {
          finishMatch();
          return;
        }
      }
      if (runtime.match.minute >= 120) {
        if (runtime.match.homeScore === runtime.match.awayScore) {
          const composure = runtime.match.homeRoster.reduce((sum, player) => sum + player.attributes.composure, 0) / 5;
          runtime.match.penalties = resolvePenaltyShootout(composure, run.opponent.rating, runtime.rng);
        }
        finishMatch();
        return;
      }
    }
    updateMatchUi();
  }
  runtime.animationFrame = requestAnimationFrame(matchLoop);
}

function updateMatchUi() {
  if (!runtime) return;
  const match = runtime.match;
  const clock = document.querySelector("#clock");
  const scoreValue = document.querySelector("#score");
  if (!clock || !scoreValue) return;
  const phase = match.minute < 45 ? "上半场" : match.minute < 90 ? "下半场" : "加时赛";
  clock.textContent = `${String(Math.floor(match.minute)).padStart(2,"0")}:00 · ${phase}`;
  scoreValue.textContent = `${match.homeScore} — ${match.awayScore}`;
  document.querySelector("#match-stats").innerHTML = `
    <small>实时数据</small>
    <div class="match-stat"><b>${match.possession.home}%</b><span>控球</span><b>${match.possession.away}%</b></div>
    <div class="match-stat"><b>${match.homeShots}</b><span>射门</span><b>${match.awayShots}</b></div>
    <div class="match-stat"><b>${match.homeXg.toFixed(2)}</b><span>预期进球</span><b>${match.awayXg.toFixed(2)}</b></div>
    <div class="match-stat"><b>${match.cards.home}</b><span>黄牌</span><b>${match.cards.away}</b></div>`;
  if (match.reds.home + match.reds.away > 0) {
    document.querySelector("#match-stats").insertAdjacentHTML("beforeend", `<div class="match-stat"><b>${match.reds.home}</b><span>红牌</span><b>${match.reds.away}</b></div>`);
  }
  const feed = document.querySelector("#event-feed");
  feed.innerHTML = match.events.length ? match.events.map((event) => `<div class="event ${event.side} ${event.type}"><b>${event.minute}'</b><span>${escapeHtml(event.text)}</span></div>`).join("") : `<div class="event empty">双方正在互相观察，顺便确认球门在哪边。</div>`;
}

function flash(text) {
  const element = document.querySelector("#match-flash");
  if (!element) return;
  element.textContent = text;
  element.classList.remove("show");
  void element.offsetWidth;
  element.classList.add("show");
}

function pauseMatch(halftime) {
  if (!runtime) return;
  runtime.running = false;
  openModal(`
    <p class="kicker">${halftime ? "HALF TIME" : "TOUCHLINE PAUSE"}</p>
    <h2>${halftime ? "中场休息" : "比赛已暂停"}</h2>
    <p>${halftime ? "球员喝水，教练可以假装刚才的一切都在计划之中。" : "比赛时间不会流动。你可以调整阵型、策略或完成换人。"}</p>
    <div class="modal-grid">
      <label><span class="field-label">场上结构</span><select class="select-control" id="pause-formation">${Object.entries(FORMATIONS).map(([key, item]) => `<option value="${key}" ${run.formation === key ? "selected" : ""}>${item.name}</option>`).join("")}</select></label>
      <label><span class="field-label">比赛策略</span><select class="select-control" id="pause-tactic">${Object.entries(TACTICS).map(([key, item]) => `<option value="${key}" ${run.tactic === key ? "selected" : ""}>${item.name}</option>`).join("")}</select></label>
    </div>
    ${substitutionControls()}
    <div class="button-row"><button class="primary-button" id="resume-match">应用并继续</button></div>`,
  () => document.querySelector("#resume-match").addEventListener("click", applyPauseChanges), false);
}

function substitutionControls() {
  const bench = runtime.homeBench;
  if (bench.length === 0) return `<p style="border-top:1px solid var(--line);padding-top:14px">替补席为空，本场无法换人。已用换人 ${runtime.match.substitutions}/2。</p>`;
  return `<div style="border-top:1px solid var(--line);padding-top:14px">
    <span class="field-label">换人 ${runtime.match.substitutions}/2</span>
    <div class="modal-grid">
      <select class="select-control" id="sub-out" ${runtime.match.substitutions >= 2 ? "disabled" : ""}>${runtime.match.homeRoster.map((player) => `<option value="${player.id}">换下 ${escapeHtml(player.name)}</option>`).join("")}</select>
      <select class="select-control" id="sub-in" ${runtime.match.substitutions >= 2 ? "disabled" : ""}>${bench.map((player) => `<option value="${player.id}">换上 ${escapeHtml(player.name)}</option>`).join("")}</select>
    </div>
    <label style="font-size:13px;color:var(--muted)"><input type="checkbox" id="make-sub" ${runtime.match.substitutions >= 2 ? "disabled" : ""}/> 本次暂停执行换人</label>
  </div>`;
}

function applyPauseChanges() {
  run.formation = document.querySelector("#pause-formation").value;
  run.tactic = document.querySelector("#pause-tactic").value;
  if (document.querySelector("#make-sub")?.checked && runtime.match.substitutions < 2) {
    const outId = document.querySelector("#sub-out").value;
    const inId = document.querySelector("#sub-in").value;
    const outIndex = runtime.match.homeRoster.findIndex((player) => player.id === outId);
    const inIndex = runtime.homeBench.findIndex((player) => player.id === inId);
    const outgoing = runtime.match.homeRoster[outIndex];
    const incoming = runtime.homeBench[inIndex];
    runtime.match.homeRoster[outIndex] = incoming;
    runtime.homeBench[inIndex] = outgoing;
    runtime.playedIds.add(incoming.id);
    runtime.match.substitutions += 1;
    showToast("换人完成");
  }
  runtime.ratings = teamRatings(runtime.match.homeRoster, run.tactic, catalog, run.formation);
  saveRun();
  closeModal();
  runtime.running = true;
  runtime.lastTime = performance.now();
  const pitch = document.querySelector("#pitch");
  if (pitch) pitch.innerHTML = `<i class="penalty-box left"></i><i class="penalty-box right"></i>${makeTokens()}<i class="ball" id="ball" style="left:50%;top:50%"></i>`;
  const rosterPanel = document.querySelector("#match-rosters");
  if (rosterPanel) rosterPanel.innerHTML = matchRosterPanel();
  moveTokens(true);
}

function finishMatch() {
  if (!runtime) return;
  runtime.running = false;
  for (const timer of runtime.visualTimers) clearTimeout(timer);
  if (runtime.animationFrame) cancelAnimationFrame(runtime.animationFrame);
  const match = structuredClone(runtime.match);
  const playedIds = new Set(runtime.playedIds);
  const penaltyWin = match.penalties && match.penalties.home > match.penalties.away;
  const won = match.homeScore > match.awayScore || penaltyWin;
  run.players.forEach((player) => {
    if (playedIds.has(player.id)) player.attributes.fitness = clamp(player.attributes.fitness - 10, 0, 100);
  });
  run.history.push({
    stage: run.stage,
    opponent: run.opponent.name,
    score: `${match.homeScore}-${match.awayScore}`,
    penalties: match.penalties ?? null,
    won,
    weather: match.weather.key,
    timeline: match.timeline,
  });
  runtime = null;
  saveRun();
  if (won) renderVictory(match);
  else renderDefeat(match);
}

function weightedRewardChoices() {
  const owned = new Set(run.players.flatMap((player) => player.traits.map((entry) => entry.id)));
  const pool = catalog.filter((trait) => !owned.has(trait.id));
  const rng = createRng(`reward-${run.stage}-${run.history.length}`);
  const rarityWeight = { common: 62, rare: 27, epic: 9, legendary: 2 };
  const choices = [];
  while (choices.length < 3 && pool.length > choices.length) {
    const available = pool.filter((trait) => !choices.includes(trait));
    const total = available.reduce((sum, trait) => sum + (rarityWeight[trait.rarity] ?? 1), 0);
    let roll = rng() * total;
    let selected = available[0];
    for (const trait of available) {
      roll -= rarityWeight[trait.rarity] ?? 1;
      if (roll <= 0) { selected = trait; break; }
    }
    choices.push(selected);
  }
  return choices;
}

function matchReport(match) {
  const important = (match.timeline ?? []).filter((event) => ["goal", "red", "card"].includes(event.type));
  return `<section class="result-report">
    <div class="result-stat-strip"><span><b>${match.possession.home}%</b><small>控球</small><b>${match.possession.away}%</b></span><span><b>${match.homeShots}</b><small>射门</small><b>${match.awayShots}</b></span><span><b>${match.homeXg.toFixed(2)}</b><small>预期进球</small><b>${match.awayXg.toFixed(2)}</b></span></div>
    <div class="timeline-head"><h3>重要时间轴</h3><small>进球、助攻与判罚记录</small></div>
    <div class="result-timeline">${important.length ? important.map((event) => `<div class="timeline-event ${event.side} ${event.type}"><b>${event.minute}'</b><i></i><span><strong>${event.type === "goal" ? `${escapeHtml(event.playerName)} · 进球` : event.type === "red" ? `${escapeHtml(event.playerName)} · 红牌` : `${escapeHtml(event.playerName)} · 黄牌`}</strong><small>${event.type === "goal" ? `${event.assistName ? `助攻 ${escapeHtml(event.assistName)}` : "无助攻"} · 当时比分 ${event.score.home}:${event.score.away} · xG ${event.xg}` : escapeHtml(event.text)}</small></span></div>`).join("") : `<p>本场没有进球或重大判罚，录像组可以提前下班。</p>`}</div>
  </section>`;
}

function renderVictory(match) {
  const choices = weightedRewardChoices();
  const gold = 100 + run.stage * 12;
  let selected = null;
  screen.innerHTML = `
    <section class="result-shell">
      <div class="result-score"><div><p class="kicker">MATCH WON · +${gold} G</p><h1>拿下<br />这一场</h1></div><div><div class="final-score">${match.homeScore}:${match.awayScore}</div>${match.penalties ? `<b>点球 ${match.penalties.home}:${match.penalties.away}</b>` : ""}</div></div>
      <div class="result-detail">
        ${matchReport(match)}
        <p class="kicker">TRAIT REWARD</p><h2>挑一张，教练</h2><p>胜利会留下点东西。选择特性卡，再指定一名球员学习；槽位满时会存入背包。</p>
        <div class="reward-options">${choices.map((trait,index) => `<button class="reward-card" data-reward="${index}"><span class="grade">${traitGrade(trait.rarity)}</span><h3>${escapeHtml(trait.name)}</h3><p>${escapeHtml(trait.summary)}</p></button>`).join("")}</div>
        <div class="reward-assign"><select id="reward-player"><option value="">先选择特性卡</option></select><button class="primary-button" id="claim-reward" disabled>学习并前往下一关</button></div>
      </div>
    </section>`;
  const cards = [...document.querySelectorAll("[data-reward]")];
  cards.forEach((card) => card.addEventListener("click", () => {
    selected = choices[Number(card.dataset.reward)];
    cards.forEach((item) => item.classList.toggle("selected", item === card));
    const maximum = run.stage >= 31 ? 3 : 2;
    const eligiblePlayers = run.players.filter((player) => player.traits.length < maximum);
    document.querySelector("#reward-player").innerHTML = eligiblePlayers.length
      ? eligiblePlayers.map((player) => `<option value="${player.id}">${escapeHtml(player.name)} · ${ROLE_LABELS[player.role]}${traitFitsRole(selected, player.role) ? " · 适配" : " · 低收益"}</option>`).join("")
      : `<option value="inventory">所有球员槽位已满，存入仓库</option>`;
    document.querySelector("#claim-reward").disabled = false;
  }));
  document.querySelector("#claim-reward").addEventListener("click", () => {
    if (!selected) return;
    const playerId = document.querySelector("#reward-player").value;
    const player = run.players.find((item) => item.id === playerId);
    if (player) player.traits.push({ id: selected.id, innate: false });
    else run.inventory.push(selected.id);
    const completedStage = run.stage;
    run.gold += gold;
    run.stage += 1;
    run.opponent = null;
    saveRun();
    if (completedStage % 3 === 0) renderRecruitReward(completedStage);
    else { prepareOpponent(); renderHub(); }
  });
}

function renderRecruitReward(completedStage) {
  const rng = createRng(`recruit-${completedStage}-${run.players.length}`);
  const roles = ["DEF", "MID", "ATT"];
  const choices = roles.map((role) => generateDraftChoices(role, catalog, rng)[0]);
  let selected = null;
  screen.innerHTML = `
    <section><header class="screen-head"><div><p class="kicker">MILESTONE REWARD · LEVEL ${completedStage}</p><h1>有人想加入球队</h1><p>每三关一次的球员三选一。新成员会先坐上替补席。</p></div></header>
    <div class="card-grid">${choices.map((player,index) => {
      const trait = getTrait(player.traits[0]?.id);
      return `<button class="player-card" data-recruit="${index}" data-number="${index+1}"><span class="player-top"><span class="role-chip">${ROLE_LABELS[player.role]}</span><span class="grade-chip">${playerOverall(player)}</span></span><h2 class="player-name">${escapeHtml(player.name)}</h2><span class="player-sub">${player.attributes.height} CM · ${escapeHtml(player.quirk)}</span><div class="stat-bars">${statBar("进攻",player.attributes.attack)}${statBar("传球",player.attributes.passing)}${statBar("防守",player.attributes.defense)}</div><div class="trait-ribbon"><small>先天特性</small><strong>${escapeHtml(trait?.name ?? "无")}</strong><p>${escapeHtml(trait?.summary ?? "")}</p></div></button>`;
    }).join("")}</div>
    <div class="draft-action"><span class="picked-list">选择后加入替补席</span><button class="primary-button" id="claim-recruit" disabled>签下球员</button></div></section>`;
  const cards = [...document.querySelectorAll("[data-recruit]")];
  cards.forEach((card) => card.addEventListener("click", () => {
    selected = Number(card.dataset.recruit);
    cards.forEach((item) => item.classList.toggle("selected", item === card));
    document.querySelector("#claim-recruit").disabled = false;
  }));
  document.querySelector("#claim-recruit").addEventListener("click", () => {
    if (selected === null) return;
    run.players.push(choices[selected]);
    saveRun();
    prepareOpponent();
    renderHub();
  });
}

function renderDefeat(match) {
  screen.innerHTML = `
    <section class="result-shell">
      <div class="result-score" style="background:var(--orange)"><div><p class="kicker">MATCH LOST</p><h1>这次<br />没踢过</h1></div><div><div class="final-score">${match.homeScore}:${match.awayScore}</div>${match.penalties ? `<b>点球 ${match.penalties.home}:${match.penalties.away}</b>` : ""}</div></div>
      <div class="result-detail"><p class="kicker">RUN CONTINUES</p><h2>征程没有重置</h2><p>失败不会清空进度。调整战术后可以重试本关，对手也不会因此嘲笑太久。</p>
        ${matchReport(match)}
        <div class="loss-actions button-row"><button class="primary-button" id="retry-stage">回更衣室重试</button><button class="secondary-button" id="title-after-loss">先回标题</button></div>
      </div>
    </section>`;
  document.querySelector("#retry-stage").addEventListener("click", () => { prepareOpponent(true); renderHub(); });
  document.querySelector("#title-after-loss").addEventListener("click", renderWelcome);
}

function openModal(content, afterOpen, closeOnBackdrop = true) {
  modal.innerHTML = content;
  modalBackdrop.hidden = false;
  modal.querySelectorAll("[data-close-modal]").forEach((button) => button.addEventListener("click", closeModal));
  modalBackdrop.onclick = closeOnBackdrop ? (event) => { if (event.target === modalBackdrop) closeModal(); } : null;
  afterOpen?.();
}

function closeModal() {
  modalBackdrop.hidden = true;
  modal.innerHTML = "";
  modalBackdrop.onclick = null;
}

async function init() {
  await loadCatalog();
  renderWelcome();
}

init();
