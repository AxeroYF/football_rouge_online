import test from "node:test";
import assert from "node:assert/strict";
import {
  createRng,
  generateDraftChoices,
  generateOpponent,
  generateOpponentSquad,
  playerOverall,
  simulateMatchFast,
  traitFitsRole,
} from "../game/public/core.js";
import { TRAIT_CARDS } from "../src/traits.js";

test("五人制选秀每次提供三个不同名字且带有先天特性", () => {
  const choices = generateDraftChoices("GK", TRAIT_CARDS, createRng("draft-test"));
  assert.equal(choices.length, 3);
  assert.equal(new Set(choices.map((player) => player.name)).size, 3);
  assert.ok(choices.every((player) => player.role === "GK"));
  assert.ok(choices.every((player) => player.traits.length === 1));
  assert.ok(choices.every((player) => Number.isInteger(playerOverall(player))));
});

test("ANY 特性可适配所有位置，专属特性只适配对应位置", () => {
  const anyTrait = TRAIT_CARDS.find((trait) => trait.eligibleRoleGroups.includes("ANY"));
  const keeperTrait = TRAIT_CARDS.find((trait) => trait.eligibleRoleGroups.length === 1 && trait.eligibleRoleGroups[0] === "GK");
  assert.ok(traitFitsRole(anyTrait, "ATT"));
  assert.ok(traitFitsRole(keeperTrait, "GK"));
  assert.equal(traitFitsRole(keeperTrait, "ATT"), false);
});

test("后期关卡生成的对手基础评级更高", () => {
  const early = generateOpponent(1, createRng("same-opponent"));
  const late = generateOpponent(40, createRng("same-opponent"));
  assert.ok(late.rating > early.rating + 25);
});

test("对手阵容包含五名首发和替补且名字唯一", () => {
  const opponent = generateOpponent(7, createRng("opponent-squad"));
  const squad = generateOpponentSquad({ ...opponent, stage: 7 }, createRng("opponent-players"), 3);
  assert.equal(squad.length, 8);
  assert.equal(new Set(squad.map((player) => player.name)).size, 8);
  assert.deepEqual(squad.slice(0, 5).map((player) => player.role), ["GK", "DEF", "MID", "MID", "ATT"]);
});

test("快速比赛会产生有效比分与射门统计", () => {
  const rng = createRng("team-test");
  const roles = ["GK", "DEF", "MID", "MID", "ATT"];
  const players = roles.map((role) => generateDraftChoices(role, TRAIT_CARDS, rng)[0]);
  const result = simulateMatchFast({ players, tactic: "balanced", formation: "121" }, TRAIT_CARDS, "match-test", 1);
  assert.equal(result.minute, 90);
  assert.ok(Number.isInteger(result.homeScore));
  assert.ok(Number.isInteger(result.awayScore));
  assert.ok(result.homeShots + result.awayShots > 0);
  assert.ok(result.timeline.length > 0);
  assert.ok(result.timeline.filter((event) => ["goal", "save", "miss"].includes(event.type)).every((event) => event.playerName));
});
