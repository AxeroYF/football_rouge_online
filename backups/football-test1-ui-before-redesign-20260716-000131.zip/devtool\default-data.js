import { TRAIT_CARDS } from "../src/traits.js";
import { makeExampleTeams } from "../src/teams.js";

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

function normalizePlayer(player, teamId, squadStatus, index) {
  return {
    ...clone(player),
    id: teamId + ":player:" + (index + 1),
    teamId,
    squadStatus,
    traitCards: player.traitCards ?? [],
    legacyTraits: player.traits ?? [],
  };
}

function normalizeTeam(team, id, playerOffset) {
  const lineup = team.lineup.map((player, index) =>
    normalizePlayer(player, id, "lineup", playerOffset + index),
  );
  const bench = (team.bench ?? []).map((player, index) =>
    normalizePlayer(player, id, "bench", playerOffset + lineup.length + index),
  );
  return {
    players: [...lineup, ...bench],
    team: {
      id,
      name: team.name,
      lineupIds: lineup.map((player) => player.id),
      benchIds: bench.map((player) => player.id),
      formation: clone(team.formation),
      tactics: clone(team.tactics),
      coach: clone(team.coach),
      chemistry: team.chemistry,
      morale: team.morale,
      form: team.form,
    },
  };
}

export function createDefaultDatabase() {
  const example = makeExampleTeams();
  const home = normalizeTeam(example.home, "river-athletic", 0);
  const away = normalizeTeam(example.away, "iron-city", 100);
  const now = new Date().toISOString();
  return {
    meta: {
      schemaVersion: 3,
      createdAt: now,
      updatedAt: now,
      title: "场边实验室",
    },
    traitCards: clone(TRAIT_CARDS),
    players: [...home.players, ...away.players],
    teams: [home.team, away.team],
    simulationPresets: [
      {
        id: "default-match",
        name: "默认测试赛",
        homeTeamId: home.team.id,
        awayTeamId: away.team.id,
        seed: "devtool-default",
        matches: 500,
        context: {
          minutes: 90,
          basePossessions: 160,
          homeAdvantage: 3.2,
          pitchQuality: 85,
          weather: {
            precipitation: 10,
            wind: 10,
            temperature: 18,
          },
          referee: {
            strictness: 50,
            penaltyBias: 50,
            homeBias: 50,
          },
        },
      },
    ],
  };
}
