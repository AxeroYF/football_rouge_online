export const ROLE_LABELS = Object.freeze({ GK: "门将", DEF: "后卫", MID: "中场", ATT: "前锋" });

export const FORMATIONS = Object.freeze({
  "121": { name: "1-2-1 稳健", slots: ["GK", "DEF", "MID", "MID", "ATT"] },
  "112": { name: "1-1-2 强攻", slots: ["GK", "DEF", "MID", "ATT", "ATT"] },
  "211": { name: "2-1-1 防守", slots: ["GK", "DEF", "DEF", "MID", "ATT"] },
});

export const TACTICS = Object.freeze({
  allOutAttack: { name: "全力进攻", attack: 15, defense: -14, tempo: 12, note: "把比赛变成烟花大会" },
  positive: { name: "积极进攻", attack: 8, defense: -5, tempo: 6, note: "主动寻找第二落点" },
  balanced: { name: "攻守平衡", attack: 0, defense: 0, tempo: 0, note: "先看清局势再下手" },
  defensive: { name: "防守反击", attack: -5, defense: 9, tempo: -3, note: "让出球权，盯住身后" },
  parkBus: { name: "全力防守", attack: -14, defense: 16, tempo: -10, note: "门前临时停车场" },
});

export const WEATHER = Object.freeze({
  sunny: { name: "晴朗", icon: "SUN", weight: 80, attack: 0, defense: 0, fatigue: 1 },
  rain: { name: "雨天", icon: "RAIN", weight: 10, attack: 1, defense: -5, fatigue: 1.2 },
  storm: { name: "雷雨", icon: "STORM", weight: 5, attack: 0, defense: -7, fatigue: 1.3 },
  snow: { name: "雪天", icon: "SNOW", weight: 5, attack: -10, defense: 1, fatigue: 1.35 },
});

const SURNAMES = ["林", "陈", "周", "江", "许", "陆", "高", "苏", "叶", "方", "赵", "罗", "顾", "沈", "夏", "魏"];
const GIVEN_NAMES = ["野", "川", "树", "舟", "昂", "远", "锐", "岳", "墨", "泉", "朗", "原", "星", "启", "湛", "骁"];
const QUIRKS = ["赛前一定先系左脚鞋带", "坚信门柱也是队友", "庆祝动作排练得比射门多", "会给每一只足球取名字", "下雨天跑得格外认真", "永远自带一卷运动胶带"];

export function createRng(seed = String(Date.now())) {
  let hash = 2166136261;
  for (const char of String(seed)) {
    hash ^= char.charCodeAt(0);
    hash = Math.imul(hash, 16777619);
  }
  return () => {
    hash += 0x6d2b79f5;
    let value = hash;
    value = Math.imul(value ^ (value >>> 15), value | 1);
    value ^= value + Math.imul(value ^ (value >>> 7), value | 61);
    return ((value ^ (value >>> 14)) >>> 0) / 4294967296;
  };
}

export function randomItem(list, rng = Math.random) {
  return list[Math.floor(rng() * list.length)];
}

export function clamp(value, minimum, maximum) {
  return Math.max(minimum, Math.min(maximum, value));
}

export function traitGrade(rarity) {
  return ({ common: "D", rare: "C", epic: "B", legendary: "A" })[rarity] ?? "D";
}

export function traitFitsRole(trait, role) {
  const roles = trait?.eligibleRoleGroups ?? [];
  return roles.includes("ANY") || roles.includes(role);
}

function rollAttribute(base, spread, rng) {
  return clamp(Math.round(base + (rng() - 0.5) * spread), 38, 88);
}

export function generatePlayer(role, traits = [], rng = Math.random, index = 0) {
  const profiles = {
    GK: { attack: 43, passing: 56, defense: 61, pace: 48, stamina: 61, composure: 65, goalkeeping: 73 },
    DEF: { attack: 48, passing: 57, defense: 72, pace: 61, stamina: 70, composure: 62, goalkeeping: 24 },
    MID: { attack: 61, passing: 72, defense: 59, pace: 65, stamina: 73, composure: 66, goalkeeping: 20 },
    ATT: { attack: 73, passing: 59, defense: 42, pace: 72, stamina: 65, composure: 67, goalkeeping: 16 },
  };
  const profile = profiles[role] ?? profiles.MID;
  const compatibleTraits = traits.filter((trait) => traitFitsRole(trait, role));
  const innate = randomItem(compatibleTraits.length ? compatibleTraits : traits, rng);
  const attributes = Object.fromEntries(
    Object.entries(profile).map(([key, value]) => [key, rollAttribute(value, 18, rng)]),
  );
  attributes.height = Math.round((role === "GK" ? 188 : role === "DEF" ? 183 : role === "ATT" ? 178 : 176) + (rng() - 0.5) * 17);
  attributes.aggression = rollAttribute(role === "DEF" ? 70 : 57, 26, rng);
  attributes.fitness = 100;

  return {
    id: `rookie-${role.toLowerCase()}-${Date.now().toString(36)}-${index}-${Math.floor(rng() * 10000)}`,
    name: randomItem(SURNAMES, rng) + randomItem(GIVEN_NAMES, rng),
    role,
    secondaryRole: role === "GK" ? null : randomItem(["DEF", "MID", "ATT"].filter((item) => item !== role), rng),
    attributes,
    morale: 70,
    hidden: {
      mentality: rollAttribute(62, 38, rng),
      injuryResistance: rollAttribute(68, 42, rng),
      emergencyGoalkeeper: rollAttribute(45, 70, rng),
    },
    quirk: randomItem(QUIRKS, rng),
    traits: innate ? [{ id: innate.id, innate: true }] : [],
  };
}

export function generateDraftChoices(role, traits, rng = Math.random) {
  const names = new Set();
  const choices = [];
  while (choices.length < 3) {
    const player = generatePlayer(role, traits, rng, choices.length);
    if (names.has(player.name)) continue;
    names.add(player.name);
    choices.push(player);
  }
  return choices;
}

export function playerOverall(player) {
  const a = player.attributes;
  const weights = {
    GK: [a.goalkeeping * 0.55, a.composure * 0.18, a.passing * 0.12, a.defense * 0.15],
    DEF: [a.defense * 0.42, a.pace * 0.17, a.stamina * 0.16, a.passing * 0.13, a.composure * 0.12],
    MID: [a.passing * 0.32, a.stamina * 0.2, a.attack * 0.18, a.defense * 0.15, a.composure * 0.15],
    ATT: [a.attack * 0.42, a.pace * 0.2, a.composure * 0.16, a.passing * 0.12, a.stamina * 0.1],
  };
  return Math.round((weights[player.role] ?? weights.MID).reduce((sum, item) => sum + item, 0));
}

function traitBonus(player, traitCatalog) {
  const traits = player.traits
    .map((entry) => traitCatalog.find((trait) => trait.id === entry.id))
    .filter(Boolean);
  const allTags = traits.flatMap((trait) => trait.tags ?? []);
  return {
    attack: allTags.filter((tag) => ["finishing", "movement", "dribbling", "shot"].includes(tag)).length * 1.8,
    midfield: allTags.filter((tag) => ["possession", "passing", "buildUp", "vision", "antiPress"].includes(tag)).length * 1.6,
    defense: allTags.filter((tag) => ["defending", "marking", "tackling", "aerial", "goalkeeping"].includes(tag)).length * 1.7,
  };
}

export function teamRatings(players, tacticKey = "balanced", traitCatalog = [], formationKey = "121") {
  const tactic = TACTICS[tacticKey] ?? TACTICS.balanced;
  const slots = FORMATIONS[formationKey]?.slots ?? FORMATIONS["121"].slots;
  let attack = 0;
  let midfield = 0;
  let defense = 0;
  let goalkeeping = 0;
  players.slice(0, 5).forEach((player, index) => {
    const a = player.attributes;
    const fit = slots[index] === player.role ? 1 : slots[index] === player.secondaryRole ? 0.88 : 0.72;
    const bonus = traitBonus(player, traitCatalog);
    attack += (a.attack * 0.52 + a.pace * 0.2 + a.composure * 0.18 + a.passing * 0.1 + bonus.attack) * fit;
    midfield += (a.passing * 0.38 + a.stamina * 0.23 + a.composure * 0.2 + a.defense * 0.1 + a.attack * 0.09 + bonus.midfield) * fit;
    defense += (a.defense * 0.4 + a.stamina * 0.2 + a.pace * 0.15 + a.composure * 0.15 + a.aggression * 0.1 + bonus.defense) * fit;
    goalkeeping += (a.goalkeeping * 0.72 + a.composure * 0.18 + a.passing * 0.1) * (slots[index] === "GK" ? 1 : 0);
  });
  return {
    attack: Math.round(attack / 5 + tactic.attack),
    midfield: Math.round(midfield / 5 + tactic.attack * 0.25 + tactic.defense * 0.2),
    defense: Math.round(defense / 5 + tactic.defense),
    goalkeeping: Math.round(goalkeeping),
    tempo: tactic.tempo,
  };
}

export function generateOpponent(stage = 1, rng = Math.random) {
  const tier = Math.ceil(stage / 10);
  const adjectives = ["桥西", "飞鸟", "白桦", "旧港", "闪电", "北岸", "橙街", "山雀"];
  const nouns = ["竞技", "联队", "工人队", "星期天队", "流浪者", "五人组"];
  const base = 48 + stage * 0.72 + tier * 1.4;
  return {
    name: `${randomItem(adjectives, rng)}${randomItem(nouns, rng)}`,
    rating: Math.round(base + (rng() - 0.5) * 7),
    tactic: randomItem(Object.keys(TACTICS), rng),
    color: randomItem(["#ff6b4a", "#7b8cff", "#f4ba41", "#d65e9d"], rng),
  };
}

export function generateOpponentSquad(opponent, rng = Math.random, benchSize = 3) {
  const roles = ["GK", "DEF", "MID", "MID", "ATT", ...Array.from({ length: benchSize }, (_, index) => ["DEF", "MID", "ATT"][index % 3])];
  const usedNames = new Set();
  return roles.map((role, index) => {
    let name = randomItem(SURNAMES, rng) + randomItem(GIVEN_NAMES, rng);
    while (usedNames.has(name)) name = randomItem(SURNAMES, rng) + randomItem(GIVEN_NAMES, rng);
    usedNames.add(name);
    return {
      id: `opponent-${opponent.stage ?? 1}-${index}-${Math.floor(rng() * 100000)}`,
      name,
      role,
      number: index + 1,
      overall: clamp(Math.round(opponent.rating + (rng() - 0.5) * 10), 38, 92),
    };
  });
}

export function pickWeather(rng = Math.random) {
  const roll = rng() * 100;
  let cursor = 0;
  for (const [key, weather] of Object.entries(WEATHER)) {
    cursor += weather.weight;
    if (roll < cursor) return { key, ...weather };
  }
  return { key: "sunny", ...WEATHER.sunny };
}

export function createMatch(team, opponent, options = {}) {
  return {
    minute: 0,
    homeScore: 0,
    awayScore: 0,
    homeShots: 0,
    awayShots: 0,
    homeXg: 0,
    awayXg: 0,
    cards: { home: 0, away: 0 },
    reds: { home: 0, away: 0 },
    possession: { home: 50, away: 50 },
    phase: "firstHalf",
    tactic: team.tactic ?? "balanced",
    formation: team.formation ?? "121",
    opponent,
    weather: options.weather ?? pickWeather(options.rng),
    homeRoster: options.homeRoster ?? team.players?.slice(0, 5) ?? [],
    awayRoster: options.awayRoster ?? opponent.squad?.slice(0, 5) ?? [],
    events: [],
    timeline: [],
    substitutions: 0,
  };
}

const COMMENTARY = {
  save: ["门将稳稳收下，顺手整理了一下发型。", "这球被挡出，防线集体松了口气。", "皮球擦柱而出，门柱今天站在防守方。"],
  miss: ["射门飞向看台，差点命中爆米花桶。", "角度有了，力量有了，准星请假了。", "皮球滑门而过，只留下一声叹息。"],
  goal: ["球进了！替补席像弹簧一样全部跳起。", "网窝一颤，这是教练板上计划过的那一种！", "进球！这脚射门连门将的影子都骗过了。"],
};

function participantWeight(player, forAssist = false) {
  const roleWeight = forAssist
    ? { GK: 0.15, DEF: 0.55, MID: 1.5, ATT: 1.05 }
    : { GK: 0.08, DEF: 0.48, MID: 1.08, ATT: 1.85 };
  const ability = player.attributes?.attack ?? player.overall ?? 60;
  return (roleWeight[player.role] ?? 1) * (0.6 + ability / 100);
}

function pickParticipant(roster, rng, excludedId = null, forAssist = false) {
  const candidates = roster.filter((player) => player.id !== excludedId);
  if (candidates.length === 0) return { id: "unknown", name: "无名球员", role: "MID" };
  const total = candidates.reduce((sum, player) => sum + participantWeight(player, forAssist), 0);
  let roll = rng() * total;
  for (const player of candidates) {
    roll -= participantWeight(player, forAssist);
    if (roll <= 0) return player;
  }
  return candidates[candidates.length - 1];
}

function recordEvent(match, event) {
  event.id = `${event.minute}-${event.type}-${match.timeline.length + 1}`;
  match.timeline.push(event);
  match.events.unshift(event);
  match.events = match.events.slice(0, 16);
  return event;
}

export function simulateMinute(match, homeRatings, rng = Math.random) {
  const weather = WEATHER[match.weather.key] ?? WEATHER.sunny;
  const awayTactic = TACTICS[match.opponent.tactic] ?? TACTICS.balanced;
  const away = {
    attack: match.opponent.rating + awayTactic.attack * 0.45 + weather.attack,
    midfield: match.opponent.rating + awayTactic.tempo * 0.2,
    defense: match.opponent.rating + awayTactic.defense * 0.45 + weather.defense,
    goalkeeping: match.opponent.rating + 3 + weather.defense,
    tempo: awayTactic.tempo,
  };
  const home = {
    ...homeRatings,
    attack: homeRatings.attack + weather.attack,
    defense: homeRatings.defense + weather.defense,
    goalkeeping: homeRatings.goalkeeping + weather.defense,
  };
  const homeShortHanded = match.reds.home * 11;
  const awayShortHanded = match.reds.away * 11;
  home.attack -= homeShortHanded;
  home.midfield -= homeShortHanded;
  home.defense -= homeShortHanded * 0.65;
  away.attack -= awayShortHanded;
  away.midfield -= awayShortHanded;
  away.defense -= awayShortHanded * 0.65;
  const possessionEdge = home.midfield - away.midfield;
  const homePossession = clamp(50 + possessionEdge * 0.45, 34, 66);
  match.possession.home = Math.round((match.possession.home * 4 + homePossession) / 5);
  match.possession.away = 100 - match.possession.home;

  const tempo = 1 + (home.tempo + away.tempo) / 90;
  const actionChance = clamp(0.12 * tempo, 0.07, 0.2);
  if (rng() > actionChance) return null;

  const homeAttacks = rng() * 100 < homePossession;
  const attacking = homeAttacks ? home : away;
  const defending = homeAttacks ? away : home;
  const edge = attacking.attack - (defending.defense * 0.58 + defending.goalkeeping * 0.42);
  const shotQuality = clamp(0.1 + (edge + 12) / 150 + rng() * 0.18, 0.06, 0.42);
  if (homeAttacks) {
    match.homeShots += 1;
    match.homeXg += shotQuality;
  } else {
    match.awayShots += 1;
    match.awayXg += shotQuality;
  }

  const isGoal = rng() < shotQuality;
  const attackingRoster = homeAttacks ? match.homeRoster : match.awayRoster;
  const shooter = pickParticipant(attackingRoster, rng);
  const assist = rng() < 0.72 ? pickParticipant(attackingRoster, rng, shooter.id, true) : null;
  const event = {
    minute: Math.max(1, Math.floor(match.minute)),
    side: homeAttacks ? "home" : "away",
    type: isGoal ? "goal" : rng() < 0.56 ? "save" : "miss",
    playerId: shooter.id,
    playerName: shooter.name,
    assistId: assist?.id ?? null,
    assistName: assist?.name ?? null,
    xg: Number(shotQuality.toFixed(2)),
  };
  if (isGoal) {
    if (homeAttacks) match.homeScore += 1;
    else match.awayScore += 1;
  }
  event.score = { home: match.homeScore, away: match.awayScore };
  event.text = isGoal
    ? `${shooter.name}破门！${assist ? `助攻来自${assist.name}。` : "这是一记没有助攻的个人表演。"}`
    : `${shooter.name}完成射门。${randomItem(COMMENTARY[event.type], rng)}`;
  recordEvent(match, event);

  const strictness = 0.018 + (weather.key === "rain" || weather.key === "storm" ? 0.01 : 0);
  if (rng() < strictness) {
    const cardSide = rng() < 0.5 ? "home" : "away";
    const isRed = rng() < 0.055;
    if (isRed) match.reds[cardSide] += 1;
    else match.cards[cardSide] += 1;
    const cardRoster = cardSide === "home" ? match.homeRoster : match.awayRoster;
    const offender = pickParticipant(cardRoster, rng);
    recordEvent(match, {
      minute: event.minute,
      side: cardSide,
      type: isRed ? "red" : "card",
      playerId: offender.id,
      playerName: offender.name,
      score: { home: match.homeScore, away: match.awayScore },
      text: isRed ? `${offender.name}被红牌罚下，球队接下来必须少一人作战。` : `${offender.name}吃到黄牌，裁判附赠了一段简短说教。`,
    });
  }
  return event;
}

export function resolvePenaltyShootout(homeComposure, awayRating, rng = Math.random) {
  let home = 0;
  let away = 0;
  for (let index = 0; index < 5; index += 1) {
    if (rng() < clamp(0.7 + (homeComposure - 60) / 240, 0.58, 0.88)) home += 1;
    if (rng() < clamp(0.7 + (awayRating - 60) / 260, 0.58, 0.86)) away += 1;
  }
  while (home === away) {
    if (rng() < 0.72) home += 1;
    if (rng() < 0.71) away += 1;
  }
  return { home, away };
}

export function simulateMatchFast(team, traitCatalog = [], seed = "test", stage = 1) {
  const rng = createRng(seed);
  const opponent = generateOpponent(stage, rng);
  opponent.squad = generateOpponentSquad({ ...opponent, stage }, rng, 3);
  const match = createMatch(team, opponent, { rng, homeRoster: team.players.slice(0, 5), awayRoster: opponent.squad.slice(0, 5) });
  const ratings = teamRatings(team.players, team.tactic, traitCatalog, team.formation);
  for (let minute = 1; minute <= 90; minute += 1) {
    match.minute = minute;
    simulateMinute(match, ratings, rng);
  }
  return match;
}
