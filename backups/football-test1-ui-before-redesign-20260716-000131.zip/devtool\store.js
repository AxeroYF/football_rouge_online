import { copyFile, mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { TRAIT_CARDS } from "../src/traits.js";
import { createDefaultDatabase } from "./default-data.js";

const here = path.dirname(fileURLToPath(import.meta.url));
const dataDirectory = path.resolve(here, "../data");
const databasePath = path.join(dataDirectory, "devtool-db.json");
const backupPath = path.join(dataDirectory, "devtool-db.backup.json");
const currentSchemaVersion = 3;

function clone(value) {
  return JSON.parse(JSON.stringify(value));
}

export function hasCorruptedText(value) {
  if (typeof value !== "string") return false;
  if (value.includes("�") || /锟斤拷|闁|鐞|鍦鸿竟/.test(value)) return true;
  const questionMarks = [...value].filter((character) => character === "?").length;
  return questionMarks >= 2 && (questionMarks / Math.max(1, value.length) >= 0.18 || /^\?+(?:\s+\S+)?$/.test(value));
}

function repairValue(current, canonical, repairs) {
  if (typeof current === "string") {
    if (hasCorruptedText(current) && typeof canonical === "string" && !hasCorruptedText(canonical)) {
      repairs.count += 1;
      return canonical;
    }
    return current;
  }
  if (Array.isArray(current)) {
    if (!Array.isArray(canonical)) return current;
    const canonicalById = new Map(
      canonical.filter((item) => item && typeof item === "object" && item.id).map((item) => [item.id, item]),
    );
    return current.map((item, index) => {
      const reference = item && typeof item === "object" && item.id
        ? canonicalById.get(item.id)
        : canonical[index];
      return repairValue(item, reference, repairs);
    });
  }
  if (current && typeof current === "object") {
    const result = {};
    for (const [key, value] of Object.entries(current)) {
      result[key] = repairValue(value, canonical?.[key], repairs);
    }
    return result;
  }
  return current;
}

export function repairCorruptedDatabaseText(state) {
  const repairs = { count: 0 };
  const repaired = repairValue(state, createDefaultDatabase(), repairs);
  return { state: repaired, repairedFields: repairs.count };
}

function migrateDatabase(state) {
  const version = Number(state?.meta?.schemaVersion ?? 1);
  if (version >= currentSchemaVersion) return { changed: false, state };
  let next = clone(state);
  if (version < 2) {
    const existingIds = new Set((next.traitCards ?? []).map((trait) => trait.id));
    const additions = TRAIT_CARDS.filter((trait) => !existingIds.has(trait.id)).map(clone);
    next.traitCards = [...(next.traitCards ?? []), ...additions];
  }
  if (version < 3) next = repairCorruptedDatabaseText(next).state;
  return {
    changed: true,
    state: {
      ...next,
      meta: { ...next.meta, schemaVersion: currentSchemaVersion },
    },
  };
}

function uniqueIds(records, label, errors) {
  const seen = new Set();
  for (const record of records) {
    if (!record?.id || typeof record.id !== "string") {
      errors.push(label + " contains record without string id");
      continue;
    }
    if (seen.has(record.id)) errors.push(label + " has duplicate id: " + record.id);
    seen.add(record.id);
  }
  return seen;
}

export function validateDatabase(state) {
  const errors = [];
  if (!state || typeof state !== "object") return ["database must be an object"];
  for (const key of ["traitCards", "players", "teams", "simulationPresets"]) {
    if (!Array.isArray(state[key])) errors.push(key + " must be an array");
  }
  if (errors.length > 0) return errors;

  const traitIds = uniqueIds(state.traitCards, "traitCards", errors);
  const playerIds = uniqueIds(state.players, "players", errors);
  const teamIds = uniqueIds(state.teams, "teams", errors);
  uniqueIds(state.simulationPresets, "simulationPresets", errors);

  for (const trait of state.traitCards) {
    if (!trait.name) errors.push("trait missing name: " + trait.id);
    if (hasCorruptedText(trait.name) || hasCorruptedText(trait.summary)) {
      errors.push("trait contains corrupted text: " + trait.id);
    }
    if (!Array.isArray(trait.eligibleRoleGroups) || trait.eligibleRoleGroups.length === 0) {
      errors.push("trait missing eligible roles: " + trait.id);
    }
    if (!Array.isArray(trait.rules)) errors.push("trait rules must be an array: " + trait.id);
  }

  for (const player of state.players) {
    if (!player.name) errors.push("player missing name: " + player.id);
    if (hasCorruptedText(player.name)) errors.push("player contains corrupted text: " + player.id);
    if (!player.role) errors.push("player missing role: " + player.id);
    if (!player.attributes || typeof player.attributes !== "object") {
      errors.push("player missing attributes: " + player.id);
    }
    if (player.teamId && !teamIds.has(player.teamId)) {
      errors.push("player references unknown team: " + player.id);
    }
    if (!Array.isArray(player.traitCards)) errors.push("player traitCards must be array: " + player.id);
    if ((player.traitCards ?? []).length > 3) errors.push("player has more than 3 traits: " + player.id);
    for (const traitId of player.traitCards ?? []) {
      if (!traitIds.has(traitId)) errors.push("player references unknown trait: " + player.id + " -> " + traitId);
    }
  }

  for (const team of state.teams) {
    if (!team.name) errors.push("team missing name: " + team.id);
    if (hasCorruptedText(team.name)) errors.push("team contains corrupted text: " + team.id);
    for (const playerId of [...(team.lineupIds ?? []), ...(team.benchIds ?? [])]) {
      if (!playerIds.has(playerId)) errors.push("team references unknown player: " + team.id + " -> " + playerId);
    }
  }

  return errors;
}

async function writeDatabase(state, createBackup) {
  const errors = validateDatabase(state);
  if (errors.length > 0) {
    const error = new Error("database validation failed");
    error.details = errors;
    throw error;
  }
  await mkdir(dataDirectory, { recursive: true });
  if (createBackup) {
    try {
      await copyFile(databasePath, backupPath);
    } catch (error) {
      if (error.code !== "ENOENT") throw error;
    }
  }
  const next = {
    ...state,
    meta: {
      ...state.meta,
      schemaVersion: currentSchemaVersion,
      updatedAt: new Date().toISOString(),
    },
  };
  await writeFile(databasePath, JSON.stringify(next, null, 2) + "\n", "utf8");
  return next;
}

export async function loadDatabase() {
  try {
    const raw = await readFile(databasePath, "utf8");
    const parsed = JSON.parse(raw);
    const migration = migrateDatabase(parsed);
    const state = migration.state;
    const errors = validateDatabase(state);
    if (errors.length > 0) {
      const error = new Error("saved database is invalid");
      error.details = errors;
      throw error;
    }
    if (migration.changed) return writeDatabase(state, true);
    return state;
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
    return writeDatabase(createDefaultDatabase(), false);
  }
}

export async function saveDatabase(state) {
  return writeDatabase(state, true);
}

export async function resetDatabase() {
  return writeDatabase(createDefaultDatabase(), true);
}

export const storePaths = Object.freeze({ dataDirectory, databasePath, backupPath });
